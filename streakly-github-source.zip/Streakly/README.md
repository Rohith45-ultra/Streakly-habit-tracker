# Streakly — Workout & Habit Planner

React / Express / tRPC / Drizzle starter, adapted from the Sandbox web-db-user template.

- `pnpm dev`: development server; honors `PORT` (default 3000).
- `pnpm build` / `pnpm start`: build and serve `dist/index.js` and `dist/public/`.
- `pnpm db:migrate`: apply checked-in migrations. `pnpm db:push`: generate and apply new schema changes.
- `pnpm check` / `pnpm test`: types and application tests.
- The AI coach calls Google's Gemini API from the server. Configure `GEMINI_API_KEY` as a protected WebDev project secret; never put its value in browser code, a repository file, or a public build.
- Chat transcripts are not persisted. The **New chat** action clears the visible conversation and restores the starter prompts.
- **Build a goal plan** turns a target outcome and brief current-habit summary into a reviewable goal, milestones, and suggested habits. Users can skip duplicate or unwanted habits; nothing is added until they choose **Add plan to Streakly**. Applied plans and selected linked habits use existing local/account data sync, and milestone progress is tracked in Progress.
- Gemini endpoints have per-IP, per-account, and per-process hourly request limits. The counters are process-local; if running multiple server replicas, move the limiter state to a shared store.

Start with the Webdev skill's default-template guide. Platform login, storage, payments and service contracts live in its shared references; read the relevant capability before extending its helper.

`server/_core/publicConfig.ts` exposes only named public runtime values. Private keys stay server-side. The platform serves managed `/manus-storage/` assets; the application does not register a second proxy.

Platform configuration is readable and editable through `webdev.config`. Default settings are initial values, not enforced constraints. The agent may modify the files, commands and configuration or follow the flexible guide for another stack.
