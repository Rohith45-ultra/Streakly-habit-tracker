# Streakly delivery outcomes

## Shared account and cross-device persistence
- [x] The same account shows the same details on mobile and PC rather than different details; signed-in app data is stored behind the authenticated user and the client shows sync/offline state.
- [x] The app is used and installed through the web rather than an app store, and browser install metadata supports both mobile and PC.

## Workout planner and timer
- [x] Users can create and manage workout plans with name, focus, duration, and exercise details.
- [x] The active workout timer provides start, pause, and reset controls with visible elapsed or remaining progress.
- [x] Phone users can complete the main task quickly with thumb-friendly controls and a responsive layout.

## Food diet and nutrition library
- [x] The Diet area includes searchable foods covering rice and other grains, meals, fruits, juices and drinks, sweets, and chocolates.
- [x] Food details show indicative per-serving calories, serving size, protein/carbohydrate/fat/fiber percentages, sugar percentage, and explanatory notes.
- [x] Users can log foods, accumulate daily calories/protein/fiber, remove logged foods, filter by category, and persist the food log with the same account-backed app data.

## Habit tracker and advanced features
- [x] The app includes onboarding cues, intuitive navigation, create/manage flows, search or filtering where useful, reminders/notifications, settings, and sensible persistence.
- [x] The tracker includes streaks, goals, flexible schedules, recovery support, insights, and dog reactions: happy when a streak continues, sad after inactivity, and supportive during recovery.

## Progress and states
- [x] The app includes graphs, bar charts, and pie charts for progress and habit/workout insights.
- [x] Loading, empty, offline, permission, error, success, and recovery states have accessible, polished mobile UI.

## AI assistant and fresh conversations
- [x] Users can open the Streakly AI coach from the tracker and ask clear questions about habits, routines, workouts, wellness, or using the app; replies are concise, kind, practical, and actionable.
- [x] Gemini requests run on the server with a protected `GEMINI_API_KEY`; the key is never included in browser code or committed files. Messages and optional tracker context are validated and bounded before sending.
- [x] The chat opens as a fresh, unpersisted conversation with starter prompts. **New chat** clears the visible transcript and returns to the starter prompts; old messages are not stored as chat history.
- [x] The coach does not claim to diagnose or treat medical conditions and directs medical or urgent concerns to a qualified professional.
- [x] The AI coach's dialog, transcript area, starter prompts, and composer use solid white backgrounds rather than transparency.

## AI goal plans and habit setup
- [x] The user can switch the AI coach to **Build a goal plan** and describe a personal destination/target outcome in a prompt of up to 500 characters, optionally including a target date, starting point, weekly availability, or constraints.
- [x] The server uses Gemini to produce and validate a goal title, summary, success measure, a realistic 2–52-week timeframe, 2–8 ordered milestones, and 2–6 habits with a name, emoji, Body/Mind/Life category, Daily/Weekdays/3× / week/Weekly frequency, and concrete goal.
- [x] The generated plan is previewed before saving. The user can include or skip each suggested habit to avoid duplicates; nothing is added until the user selects **Add plan to Streakly**. Applying creates one saved goal linked to only the selected new habits while preserving existing habits and other tracker data. Guest plans persist in local storage, and signed-in plans sync through the existing account data.
- [x] Saved plans appear in Progress with milestone completion controls and progress; removing a goal does not delete the habits that were already added to the Habits list.
- [x] The planner explains that the goal prompt and a concise current-habit summary are sent to Gemini; the Gemini credential remains server-side and no generated plan is persisted before the user applies it.
- [x] The planner gives general, non-diagnostic habit guidance, avoids extreme exercise or diet prescriptions, and includes an appropriate qualified-care note for goals that require professional medical advice.
- [x] Both Gemini endpoints reject excess calls before contacting the provider: per hour, chat allows 60 requests per IP, 30 per account, and 300 per process; goal planning allows 12 per IP, 6 per account, and 100 per process. Rate-limit responses include a retry delay.

## Permanent website publication
- [ ] The existing Streakly app, its real account flow, PWA, and tracker features run from the managed production container with the existing managed MySQL persistence and unauthenticated `/api/health` readiness route.
- [ ] The tested source is saved as a canonical `main` checkpoint and that checkpoint is successfully published to the permanent website. The production Gemini credential is supplied through the protected secret flow, not through source or browser configuration.
