import { trpc } from "@/lib/trpc";
import type { GoalPlanDraft, SavedGoal } from "@shared/goalPlan";
import { ArrowRight, Check, Clock3, Loader2, Sparkles, Target, Trash2 } from "lucide-react";
import { useState } from "react";

type LinkedHabit = {
  id: string;
  name: string;
  emoji: string;
  frequency: string;
  goal: string;
};

type AIGoalPlannerProps = {
  context: string;
  onApply: (plan: GoalPlanDraft) => void;
};

export function AIGoalPlanner({ context, onApply }: AIGoalPlannerProps) {
  const [goal, setGoal] = useState("");
  const [draft, setDraft] = useState<GoalPlanDraft | null>(null);
  const [selectedHabitIndexes, setSelectedHabitIndexes] = useState<number[]>([]);
  const createPlan = trpc.ai.createGoalPlan.useMutation();

  const generatePlan = async () => {
    const prompt = goal.trim();
    if (prompt.length < 8 || createPlan.isPending) return;
    createPlan.reset();
    try {
      const result = await createPlan.mutateAsync({ goal: prompt, context });
      setDraft(result);
      setSelectedHabitIndexes(result.habits.map((_, index) => index));
    } catch {
      // The mutation error is rendered below without exposing server credentials.
    }
  };

  return (
    <div className="goal-planner" aria-live="polite">
      {!draft ? (
        <>
          <div className="goal-planner-intro">
            <span className="goal-planner-icon"><Target size={20} /></span>
            <div>
              <span className="goal-planner-kicker">START WITH THE OUTCOME</span>
              <h3>What would you like to reach?</h3>
              <p>Streakly will turn your destination goal into small habits and a clear path forward.</p>
            </div>
          </div>

          <form onSubmit={event => { event.preventDefault(); void generatePlan(); }} className="goal-planner-form">
            <label htmlFor="streakly-goal-prompt">Your goal</label>
            <textarea
              id="streakly-goal-prompt"
              value={goal}
              onChange={event => setGoal(event.target.value.slice(0, 500))}
              maxLength={500}
              rows={5}
              placeholder="For example: I want to run my first 5K this spring. I can train three days a week and I’m new to running."
            />
            <div className="goal-planner-input-meta">
              <span>Optional: include a target date, your starting point, weekly availability, or constraints.</span>
              <span>{goal.length}/500</span>
            </div>
            {createPlan.error && <p className="goal-planner-error" role="alert">{createPlan.error.message || "We couldn't create a plan just now. Please try again."}</p>}
            <button className="goal-primary-button goal-generate-button" type="submit" disabled={goal.trim().length < 8 || createPlan.isPending}>
              {createPlan.isPending ? <><Loader2 className="goal-spin" size={16} /> Building your plan…</> : <>Build my plan <ArrowRight size={16} /></>}
            </button>
          </form>

          <p className="goal-privacy-note">Your goal and a short summary of current habits are sent to Google Gemini to draft the plan. Nothing is saved until you choose <strong>Add plan to Streakly</strong>.</p>
        </>
      ) : (
        <>
          <div className="goal-draft-heading">
            <span className="goal-planner-kicker"><Sparkles size={13} /> YOUR AI-GENERATED PLAN</span>
            <h3>{draft.title}</h3>
            <p>{draft.summary}</p>
            <div className="goal-draft-meta">
              <div><span>TIMEFRAME</span><strong><Clock3 size={14} />{draft.timeframeWeeks} weeks</strong></div>
              <div><span>SUCCESS MEANS</span><strong>{draft.successMetric}</strong></div>
            </div>
          </div>

          <section className="goal-draft-section" aria-labelledby="goal-draft-milestones">
            <h4 id="goal-draft-milestones">Milestones</h4>
            <div className="goal-draft-milestones">
              {draft.milestones.map((milestone, index) => (
                <div className="goal-draft-milestone" key={`${milestone.week}-${index}`}>
                  <span>{index + 1}</span>
                  <div><strong>Week {milestone.week}: {milestone.title}</strong><p>{milestone.description}</p></div>
                </div>
              ))}
            </div>
          </section>

          <section className="goal-draft-section" aria-labelledby="goal-draft-habits">
            <div><h4 id="goal-draft-habits">Habits to add ({selectedHabitIndexes.length})</h4><p className="goal-habit-selection-hint">Unselect any suggestion you already track or don’t want to add.</p></div>
            <div className="goal-draft-habits">
              {draft.habits.map((habit, index) => {
                const selected = selectedHabitIndexes.includes(index);
                return <button className={`goal-draft-habit ${selected ? "is-selected" : "is-excluded"}`} type="button" key={`${habit.name}-${index}`} aria-pressed={selected} onClick={() => setSelectedHabitIndexes(current => current.includes(index) ? current.filter(item => item !== index) : [...current, index].sort((left, right) => left - right))}>
                  <span className={`goal-habit-select ${selected ? "is-selected" : ""}`} aria-hidden="true">{selected && <Check size={12} />}</span>
                  <span className="goal-draft-habit-emoji" aria-hidden="true">{habit.emoji}</span>
                  <div><strong>{habit.name}</strong><span>{habit.category} · {habit.frequency}</span></div>
                  <small>{habit.goal}</small>
                </button>;
              })}
            </div>
          </section>

          {draft.safetyNote && <p className="goal-safety-note">{draft.safetyNote}</p>}
          <p className="goal-privacy-note">Review this draft before applying it. Your goal and current-habit summary are sent to Google Gemini; the plan is only saved when you choose <strong>Add plan to Streakly</strong>.</p>
          <div className="goal-planner-actions">
            <button className="goal-secondary-button" type="button" onClick={() => { setDraft(null); createPlan.reset(); }}>Edit goal</button>
            <button className="goal-primary-button" type="button" onClick={() => onApply({ ...draft, habits: draft.habits.filter((_, index) => selectedHabitIndexes.includes(index)) })}><Check size={16} /> {selectedHabitIndexes.length ? `Add plan & ${selectedHabitIndexes.length} ${selectedHabitIndexes.length === 1 ? "habit" : "habits"}` : "Save goal only"}</button>
          </div>
        </>
      )}
    </div>
  );
}

type GoalPlansSectionProps = {
  goals: SavedGoal[];
  habits: LinkedHabit[];
  onCreatePlan: () => void;
  onToggleMilestone: (goalId: string, milestoneIndex: number) => void;
  onRemoveGoal: (goalId: string) => void;
};

export function GoalPlansSection({ goals, habits, onCreatePlan, onToggleMilestone, onRemoveGoal }: GoalPlansSectionProps) {
  const habitsById = new Map(habits.map(habit => [habit.id, habit]));

  return (
    <section className="goal-plans-section page-section" aria-labelledby="goal-plans-heading">
      <div className="goal-plans-heading">
        <div>
          <span className="eyebrow">YOUR DESTINATION</span>
          <h2 id="goal-plans-heading">Goals &amp; plans</h2>
          <p>Big intentions, broken into kind and doable steps.</p>
        </div>
        <button className="goal-primary-button" type="button" onClick={onCreatePlan}><Sparkles size={16} /> Plan with AI</button>
      </div>

      {goals.length === 0 ? (
        <div className="goal-empty-state">
          <span className="goal-planner-icon"><Target size={21} /></span>
          <div><strong>Your next chapter starts with a goal.</strong><p>Tell Streakly what you want to reach, then review a plan of habits and milestones before adding it.</p></div>
          <button className="goal-secondary-button" type="button" onClick={onCreatePlan}>Build my first plan <ArrowRight size={15} /></button>
        </div>
      ) : (
        <div className="goal-plans-list">
          {goals.map(goal => {
            const completed = goal.completedMilestones ?? [];
            const progress = Math.round((completed.length / Math.max(goal.milestones.length, 1)) * 100);
            const linkedHabits = (goal.habitIds ?? []).map(id => habitsById.get(id)).filter((habit): habit is LinkedHabit => Boolean(habit));
            return (
              <article className="goal-plan-card" key={goal.id}>
                <div className="goal-plan-card-heading">
                  <div><span className="goal-plan-badge"><Sparkles size={12} /> AI PLAN · {goal.timeframeWeeks} WEEKS</span><h3>{goal.title}</h3></div>
                  <button className="goal-remove-button" type="button" onClick={() => onRemoveGoal(goal.id)} aria-label={`Remove goal ${goal.title}`} title="Remove goal; habits will remain"><Trash2 size={16} /></button>
                </div>
                <p className="goal-plan-summary">{goal.summary}</p>
                <div className="goal-progress-meta"><span>Milestone progress</span><strong>{completed.length} of {goal.milestones.length} · {progress}%</strong></div>
                <div className="goal-progress-track" role="progressbar" aria-label={`${goal.title} milestone progress`} aria-valuenow={progress} aria-valuemin={0} aria-valuemax={100}><span style={{ width: `${progress}%` }} /></div>
                <p className="goal-success-metric"><strong>Success measure:</strong> {goal.successMetric}</p>

                <div className="goal-saved-milestones">
                  <h4>Milestones</h4>
                  {goal.milestones.map((milestone, index) => {
                    const isComplete = completed.includes(index);
                    return (
                      <button className={`goal-saved-milestone ${isComplete ? "is-complete" : ""}`} type="button" key={`${milestone.week}-${index}`} onClick={() => onToggleMilestone(goal.id, index)} aria-pressed={isComplete}>
                        <span className="goal-milestone-check">{isComplete ? <Check size={13} /> : milestone.week}</span>
                        <span className="goal-saved-milestone-copy"><strong>Week {milestone.week}: {milestone.title}</strong><small>{milestone.description}</small></span>
                      </button>
                    );
                  })}
                </div>

                <div className="goal-linked-habits">
                  <div><h4>Habits added to your tracker</h4><p>Removing this goal will keep these habits in your Habits list.</p></div>
                  {linkedHabits.length ? <div className="goal-linked-habit-list">{linkedHabits.map(habit => <span key={habit.id}>{habit.emoji} {habit.name} · {habit.frequency} · {habit.goal}</span>)}</div> : <span className="goal-no-linked-habits">No linked habits found.</span>}
                </div>
              </article>
            );
          })}
        </div>
      )}
    </section>
  );
}
