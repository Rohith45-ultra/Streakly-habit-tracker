import { Check, Flame, Leaf, Minus, Plus, Search, Trash2, Utensils } from "lucide-react";
import { useMemo, useState } from "react";

export type Food = {
  id: string;
  name: string;
  category: "Grains" | "Meals" | "Fruits" | "Drinks" | "Sweets" | "Chocolate";
  serving: string;
  calories: number;
  emoji: string;
  protein: number;
  carbs: number;
  fat: number;
  fiber: number;
  sugar: number;
  note: string;
};

export type DietLogEntry = { id: string; foodId: string; servings: number };

export const FOOD_LIBRARY: Food[] = [
  { id: "white-rice", name: "White rice", category: "Grains", serving: "1 cup cooked", calories: 206, emoji: "🍚", protein: 10, carbs: 17, fat: 3, fiber: 4, sugar: 1, note: "Steamed, plain" },
  { id: "brown-rice", name: "Brown rice", category: "Grains", serving: "1 cup cooked", calories: 215, emoji: "🍚", protein: 11, carbs: 16, fat: 4, fiber: 14, sugar: 1, note: "Whole grain" },
  { id: "biryani", name: "Vegetable biryani", category: "Meals", serving: "1 medium bowl", calories: 380, emoji: "🥘", protein: 14, carbs: 23, fat: 17, fiber: 10, sugar: 4, note: "Rice with vegetables" },
  { id: "dal-rice", name: "Dal with rice", category: "Meals", serving: "1 bowl", calories: 360, emoji: "🍛", protein: 21, carbs: 25, fat: 10, fiber: 22, sugar: 3, note: "Lentils and rice" },
  { id: "idli", name: "Idli", category: "Meals", serving: "2 pieces", calories: 116, emoji: "⚪", protein: 8, carbs: 15, fat: 2, fiber: 5, sugar: 1, note: "Steamed rice cakes" },
  { id: "chapati", name: "Chapati", category: "Grains", serving: "1 medium", calories: 120, emoji: "🫓", protein: 8, carbs: 9, fat: 4, fiber: 8, sugar: 1, note: "Whole wheat" },
  { id: "oats", name: "Oats porridge", category: "Grains", serving: "1 bowl", calories: 150, emoji: "🥣", protein: 13, carbs: 11, fat: 8, fiber: 16, sugar: 2, note: "Cooked with water" },
  { id: "banana", name: "Banana", category: "Fruits", serving: "1 medium", calories: 105, emoji: "🍌", protein: 3, carbs: 9, fat: 1, fiber: 13, sugar: 22, note: "Fresh fruit" },
  { id: "apple", name: "Apple", category: "Fruits", serving: "1 medium", calories: 95, emoji: "🍎", protein: 1, carbs: 7, fat: 0, fiber: 14, sugar: 20, note: "With skin" },
  { id: "orange-juice", name: "Orange juice", category: "Drinks", serving: "1 glass · 240 ml", calories: 112, emoji: "🍊", protein: 4, carbs: 9, fat: 0, fiber: 0, sugar: 42, note: "100% juice" },
  { id: "mango-juice", name: "Mango juice", category: "Drinks", serving: "1 glass · 240 ml", calories: 150, emoji: "🥭", protein: 2, carbs: 13, fat: 1, fiber: 4, sugar: 58, note: "No added sugar" },
  { id: "coconut-water", name: "Coconut water", category: "Drinks", serving: "1 glass · 240 ml", calories: 46, emoji: "🥥", protein: 2, carbs: 4, fat: 0, fiber: 0, sugar: 11, note: "Unsweetened" },
  { id: "gulab-jamun", name: "Gulab jamun", category: "Sweets", serving: "1 piece", calories: 150, emoji: "🍮", protein: 4, carbs: 9, fat: 12, fiber: 0, sugar: 24, note: "Syrup sweet" },
  { id: "rasgulla", name: "Rasgulla", category: "Sweets", serving: "1 piece", calories: 125, emoji: "🍡", protein: 5, carbs: 10, fat: 4, fiber: 0, sugar: 25, note: "Cottage cheese sweet" },
  { id: "ice-cream", name: "Vanilla ice cream", category: "Sweets", serving: "1 scoop · 100 g", calories: 207, emoji: "🍨", protein: 7, carbs: 9, fat: 16, fiber: 0, sugar: 28, note: "Classic vanilla" },
  { id: "dark-chocolate", name: "Dark chocolate", category: "Chocolate", serving: "30 g", calories: 170, emoji: "🍫", protein: 6, carbs: 6, fat: 24, fiber: 11, sugar: 18, note: "70% cocoa" },
  { id: "milk-chocolate", name: "Milk chocolate", category: "Chocolate", serving: "30 g", calories: 160, emoji: "🍫", protein: 6, carbs: 8, fat: 23, fiber: 4, sugar: 34, note: "Classic bar" },
  { id: "dates", name: "Dates", category: "Sweets", serving: "3 dates", calories: 132, emoji: "🌴", protein: 4, carbs: 6, fat: 0, fiber: 14, sugar: 51, note: "Naturally sweet" },
];

const categories = ["All", "Grains", "Meals", "Fruits", "Drinks", "Sweets", "Chocolate"] as const;

export default function DietView({ entries, onLog, onRemove }: { entries: DietLogEntry[]; onLog: (foodId: string, servings: number) => void; onRemove: (foodId: string) => void }) {
  const [query, setQuery] = useState("");
  const [category, setCategory] = useState<(typeof categories)[number]>("All");
  const filtered = useMemo(() => FOOD_LIBRARY.filter(food => (category === "All" || food.category === category) && `${food.name} ${food.note}`.toLowerCase().includes(query.toLowerCase())), [category, query]);
  const logged = entries.map(entry => ({ entry, food: FOOD_LIBRARY.find(food => food.id === entry.foodId) })).filter(item => item.food);
  const calories = logged.reduce((sum, item) => sum + (item.food?.calories ?? 0) * item.entry.servings, 0);
  const protein = logged.reduce((sum, item) => sum + (item.food?.protein ?? 0) * item.entry.servings, 0);
  const fiber = logged.reduce((sum, item) => sum + (item.food?.fiber ?? 0) * item.entry.servings, 0);

  return <section className="page-section diet-section"><div className="page-intro"><div><span className="eyebrow">NOURISH YOUR RHYTHM</span><h1>Food that fuels your day.</h1><p>Explore familiar foods, see the serving-level picture, and build a balanced log without the guesswork.</p></div><div className="diet-note"><Leaf size={17} /><span>Indicative values per serving</span></div></div><div className="diet-summary"><div><Flame size={20} /><strong>{calories}</strong><span>calories logged today</span></div><div><strong>{protein} g</strong><span>estimated protein</span></div><div><strong>{fiber} g</strong><span>estimated fiber</span></div><div className="diet-summary-track"><div style={{ width: `${Math.min(100, (calories / 2000) * 100)}%` }} /></div></div><div className="diet-layout"><div className="diet-library"><div className="diet-toolbar"><div className="search-field"><Search size={17} /><input value={query} onChange={event => setQuery(event.target.value)} placeholder="Search rice, juice, chocolate…" aria-label="Search foods" /></div><div className="filter-pills">{categories.map(item => <button key={item} className={category === item ? "active" : ""} onClick={() => setCategory(item)}>{item}</button>)}</div></div><div className="food-grid">{filtered.map(food => <FoodCard key={food.id} food={food} onLog={() => onLog(food.id, 1)} />)}</div>{filtered.length === 0 && <div className="empty-state"><div className="empty-icon"><Search size={22} /></div><h3>No foods found</h3><p>Try rice, fruit, juice, sweets, or chocolate.</p></div>}</div><aside className="diet-log-card"><div className="section-title"><div><span className="eyebrow">TODAY</span><h2>Your food log</h2></div><Utensils size={20} /></div>{logged.length === 0 ? <div className="diet-empty"><Utensils size={22} /><p>Start with one serving and build from there.</p></div> : <div className="diet-log-list">{logged.map(({ entry, food }) => food && <div className="diet-log-row" key={entry.foodId}><span>{food.emoji}</span><div><strong>{food.name}</strong><small>{entry.servings} serving{entry.servings > 1 ? "s" : ""} · {food.calories * entry.servings} kcal</small></div><button onClick={() => onRemove(entry.foodId)} aria-label={`Remove ${food.name}`}><Trash2 size={15} /></button></div>)}</div>}<p className="diet-disclaimer">Nutrition values are estimates and can vary by recipe, brand, and serving size. Use product labels or a registered dietitian for medical or therapeutic needs.</p></aside></div></section>;
}

function FoodCard({ food, onLog }: { food: Food; onLog: () => void }) {
  return <article className="food-card"><div className="food-card-top"><span className="food-emoji">{food.emoji}</span><span className="food-category">{food.category}</span></div><h3>{food.name}</h3><p>{food.serving} · {food.note}</p><div className="food-calories"><strong>{food.calories}</strong><span>kcal</span><button onClick={onLog}><Plus size={15} />Log</button></div><div className="nutrient-grid"><Nutrient label="Protein" value={food.protein} color="protein" /><Nutrient label="Carbs" value={food.carbs} color="carbs" /><Nutrient label="Fat" value={food.fat} color="fat" /><Nutrient label="Fiber" value={food.fiber} color="fiber" /></div><div className="sugar-row"><span>Sugars</span><span>{food.sugar}% of daily target</span></div></article>;
}

function Nutrient({ label, value, color }: { label: string; value: number; color: string }) { return <div className="nutrient"><div><span>{label}</span><strong>{value}%</strong></div><span className={`nutrient-bar ${color}`}><i style={{ width: `${Math.min(100, value)}%` }} /></span></div>; }
