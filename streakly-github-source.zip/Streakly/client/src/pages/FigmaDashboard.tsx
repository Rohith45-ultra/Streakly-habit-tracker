import type { AppData, Habit } from "./Home";
import { ArrowUpRight, Bell, BookOpen, Check, ChevronDown, Ellipsis, Leaf, MoreHorizontal, NotebookPen, PersonStanding, Plus, Sprout, Sun, Trees, Utensils, Wind } from "lucide-react";

const iconForHabit: Record<string, React.ReactNode> = {
  water: <span className="figma-emoji">◌</span>,
  read: <BookOpen size={21} strokeWidth={1.7} />,
  stretch: <PersonStanding size={21} strokeWidth={1.7} />,
  walk: <Trees size={21} strokeWidth={1.7} />,
};

function habitIcon(habit: Habit) {
  if (iconForHabit[habit.id]) return iconForHabit[habit.id];
  if (habit.category === "Body") return <Wind size={21} strokeWidth={1.7} />;
  if (habit.category === "Mind") return <NotebookPen size={21} strokeWidth={1.7} />;
  return <Leaf size={21} strokeWidth={1.7} />;
}

function displayGoal(habit: Habit) {
  const labels: Record<string, string> = { "8 glasses": "Drink water", "10 pages": "Read", "5 minutes": "Gentle stretching", "20 minutes": "Walk outside" };
  return `${labels[habit.goal] ?? habit.category} · ${habit.goal}`;
}

export default function FigmaDashboard({ data, userName, onComplete, onNavigate, onNewHabit, onIncrement }: { data: AppData; userName?: string | null; onComplete: (id: string) => void; onNavigate: (tab: "habits" | "progress" | "settings" | "diet") => void; onNewHabit: () => void; onIncrement: (id: string) => void }) {
  const completed = data.habits.filter(habit => habit.completedToday).length;
  const total = Math.max(data.habits.length, 1);
  const percent = Math.round((completed / total) * 100);
  const bestStreak = Math.max(...data.habits.map(habit => habit.streak), 0);
  const monthWins = data.habits.reduce((sum, habit) => sum + habit.bestStreak, 0);
  const days = ["Wed", "Thu", "Fri", "Sat", "Sun", "Mon", "Tue"];
  const values = data.activity.slice(-7).map(day => day.habits);
  const maxValue = Math.max(...values, 1);
  const shownHabits = data.habits.slice(0, 6);

  return <div className="figma-dashboard">
    <header className="figma-topbar"><div className="figma-location"><Sun size={18} strokeWidth={1.7} /><strong>My day</strong><span>/</span><em>A fresh start</em></div><div className="figma-actions"><button className="figma-diet-button" onClick={() => onNavigate("diet")}><Utensils size={15} />Diet</button><button className="figma-icon-button" aria-label="Notifications" onClick={() => onNavigate("settings")}><Bell size={19} strokeWidth={1.7} /><i /></button><button className="figma-new-button" onClick={onNewHabit}><Plus size={16} />New habit</button></div></header>
    <main className="figma-workspace">
      <div className="figma-welcome"><div><h1>A little better, every day.</h1><p>Good morning{userName ? `, ${userName.split(" ")[0]}` : ""}. Make a little room for yourself today.</p></div><div className="figma-date">{new Intl.DateTimeFormat("en-US", { weekday: "long", month: "long", day: "numeric" }).format(new Date())}</div></div>
      <div className="figma-overview-row"><div className="figma-progress-card"><div className="figma-ring" style={{ background: `conic-gradient(#427356 ${percent * 3.6}deg, #d7e2ce 0deg)` }}><div><strong>{percent}%</strong><span>of your day</span></div></div><div><small>LITTLE WINS ADD UP</small><h2>{completed > 0 ? "You’re making space for you." : "Let’s find one small win."}</h2><p>{completed} of {total} habits complete. A few small steps, and you’re already moving forward.</p></div></div><div className="figma-growth-card"><div><Sprout size={20} strokeWidth={1.7} /><strong>{bestStreak} days</strong><span>showing up for you</span></div><div className="figma-divider" /><div><span className="figma-check-icon"><Check size={13} /></span><strong>{monthWins}</strong><span>little wins this month</span></div></div></div>
      <div className="figma-content-grid"><section className="figma-habits-card"><div className="figma-section-head"><div><h2>Today’s habits <sup>{data.habits.length}</sup></h2><div className="figma-tabs"><button className="active">Today</button><button>Upcoming</button></div></div><button className="figma-filter" onClick={() => onNavigate("habits")}>All habits <ChevronDown size={14} /></button></div><div className="figma-habit-list">{shownHabits.map(habit => <FigmaHabitRow key={habit.id} habit={habit} onComplete={() => onComplete(habit.id)} onIncrement={() => onIncrement(habit.id)} />)}</div><button className="figma-plant-button" onClick={onNewHabit}><Plus size={15} />Plant a new habit</button></section><aside className="figma-side-column"><section className="figma-week-card"><div className="figma-side-title"><h2>Your week in bloom</h2><button onClick={() => onNavigate("progress")} aria-label="Open progress"><ArrowUpRight size={18} /></button></div><div className="figma-week-meta"><span>Last 7 days</span><span><i />Habits completed</span></div><div className="figma-bars">{days.map((day, index) => { const value = values[index] ?? 0; return <div className="figma-bar-day" key={day}><div className="figma-bar-track"><div className="figma-bar-fill" style={{ height: `${Math.max(18, (value / maxValue) * 100)}%`, opacity: index === 6 ? 1 : .42 + index * .05 }}><span>{value}</span></div></div><small>{day}</small><em>{21 + index}</em></div>; })}</div><div className="figma-week-footer"><Leaf size={20} /><span>{monthWins} small wins. Every one counts.</span></div></section><section className="figma-feeling-card"><div><small><Sun size={14} /> A MOMENT FOR YOU</small><h2>How are you feeling today?</h2><p>Pause, take a breath, and check in with yourself.</p><button onClick={() => onNavigate("settings")}>Write a little <ArrowUpRight size={15} /></button></div><img src="/figma-assets/2-1526.webp" alt="Soft botanical leaves" /></section></aside></div>
    </main>
  </div>;
}

function FigmaHabitRow({ habit, onComplete, onIncrement }: { habit: Habit; onComplete: () => void; onIncrement: () => void }) {
  const isCountable = habit.id === "water";
  return <div className="figma-habit-row"><button className={`figma-complete ${habit.completedToday ? "done" : ""}`} onClick={onComplete} aria-label={`${habit.completedToday ? "Uncheck" : "Complete"} ${habit.name}`}>{habit.completedToday && <Check size={15} />}</button><span className="figma-habit-symbol">{habitIcon(habit)}</span><div className="figma-habit-copy"><strong>{habit.name}</strong><span>{displayGoal(habit)}</span></div>{isCountable && !habit.completedToday ? <div className="figma-increment"><span>4 / 8</span><button onClick={onIncrement} aria-label="Add one glass"><Plus size={15} /></button></div> : <span className="figma-category">{habit.category}</span>}<button className="figma-more" aria-label={`More options for ${habit.name}`}><MoreHorizontal size={17} /></button></div>;
}
