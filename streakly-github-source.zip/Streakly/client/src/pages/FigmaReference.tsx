export default function FigmaReference() {
  return (
    <div data-layer="Dashboard" data-node-id="2-1336" className="Dashboard self-stretch inline-flex flex-col justify-start items-start overflow-hidden">
  <div data-layer="Top bar" data-node-id="2-1337" className="TopBar self-stretch h-[84px] px-10 border-b border-[#e7ebe3] inline-flex justify-between items-center overflow-hidden">
    <div data-layer="Page location" data-node-id="2-1338" className="PageLocation flex justify-start items-center gap-2.5 overflow-hidden">
      <div data-layer="sun" data-node-id="2-1563" className="Sun w-[18px] h-[18px] relative overflow-hidden">
        <img data-layer="Vector" data-node-id="2-1564" className="Vector w-[15px] h-[15px] left-[1.50px] top-[1.50px] absolute" src="/figma-assets/2-1564.svg" />
      </div>
      <div data-layer="Page name" data-node-id="2-1340" className="PageName justify-start text-[#293d32] text-sm font-medium font-['Inter']">My day</div>
      <div data-layer="Separator" data-node-id="2-1341" className="Separator justify-start text-[#d7e2ce] text-sm font-normal font-['Inter']">/</div>
      <div data-layer="Context" data-node-id="2-1342" className="Context justify-start text-[#7b857b] text-[13px] font-normal font-['Inter']">A fresh start</div>
    </div>
    <div data-layer="Page actions" data-node-id="2-1343" className="PageActions flex justify-start items-center gap-[22px] overflow-hidden">
      <div data-layer="Notifications" data-node-id="2-1344" className="Notifications w-6 h-7 relative flex justify-start items-center overflow-hidden">
        <div data-layer="bell" data-node-id="2-1566" className="Bell w-5 h-5 relative overflow-hidden">
          <img data-layer="Vector" data-node-id="2-1567" className="Vector w-[15px] h-[16.67px] left-[2.50px] top-[1.67px] absolute" src="/figma-assets/2-1567.svg" />
        </div>
        <div data-layer="Unread notification" data-node-id="2-1346" className="UnreadNotification w-[5px] h-[5px] left-[16px] top-[2px] absolute bg-[#427356] rounded-full" />
      </div>
      <div data-layer="Action" data-node-id="2-1347" className="Action px-4 py-3 bg-[#427356] rounded-xl outline outline-1 outline-offset-[-1px] outline-[#427356] flex justify-start items-center gap-2 overflow-hidden">
        <div data-layer="plus" data-node-id="2-1569" className="Plus w-4 h-4 relative overflow-hidden">
          <img data-layer="Vector" data-node-id="2-1570" className="Vector w-[9.33px] h-[9.33px] left-[3.33px] top-[3.33px] absolute" src="/figma-assets/2-1570.svg" />
        </div>
        <div data-layer="Label" data-node-id="2-1349" className="Label justify-start text-white text-[13px] font-medium font-['Inter']">New habit</div>
      </div>
    </div>
  </div>
  <div data-layer="Daily workspace" data-node-id="2-1350" className="DailyWorkspace self-stretch px-10 pt-8 pb-7 flex flex-col justify-start items-start gap-7 overflow-hidden">
    <div data-layer="Welcome" data-node-id="2-1351" className="Welcome self-stretch inline-flex justify-between items-center overflow-hidden">
      <div data-layer="Greeting" data-node-id="2-1352" className="Greeting inline-flex flex-col justify-start items-start gap-2 overflow-hidden">
        <div data-layer="Title" data-node-id="2-1353" className="Title justify-start text-[#293d32] text-[34px] font-normal font-['Lora']">A little better, every day.</div>
        <div data-layer="Supporting message" data-node-id="2-1354" className="SupportingMessage justify-start text-[#5f6f62] text-sm font-normal font-['Inter']">Good morning, Alex. Make a little room for yourself today.</div>
      </div>
      <div data-layer="Date" data-node-id="2-1355" className="Date px-3.5 py-2.5 bg-white rounded-xl outline outline-1 outline-offset-[-1px] outline-[#e7ebe3] flex justify-start items-start gap-2 overflow-hidden">
        <div data-layer="Current date" data-node-id="2-1356" className="CurrentDate justify-start text-[#5f6f62] text-[13px] font-normal font-['Inter']">Tuesday, October 27</div>
      </div>
    </div>
    <div data-layer="Daily overview" data-node-id="2-1357" className="DailyOverview self-stretch h-[174px] inline-flex justify-start items-start gap-6 overflow-hidden">
      <div data-layer="Today’s progress" data-node-id="2-1358" className="TodaySProgress flex-1 self-stretch p-7 bg-[#e7eedf] rounded-[20px] flex justify-start items-center gap-7 overflow-hidden">
        <div data-layer="Completion ring" data-node-id="2-1359" className="CompletionRing w-28 h-28 relative flex justify-center items-center overflow-hidden">
          <div data-layer="Progress track" data-node-id="2-1360" className="ProgressTrack w-28 h-28 left-0 top-0 absolute bg-black/0 rounded-full border-8 border-[#d7e2ce]" />
          <div data-layer="Completed portion" data-node-id="2-1361" className="CompletedPortion w-28 h-28 left-0 top-0 absolute bg-[#427356] rounded-full" />
          <div data-layer="Progress value" data-node-id="2-1362" className="ProgressValue inline-flex flex-col justify-start items-center gap-px overflow-hidden">
            <div data-layer="Percentage" data-node-id="2-1363" className="Percentage justify-start text-[#293d32] text-[29px] font-normal font-['Lora']">50%</div>
            <div data-layer="Label" data-node-id="2-1364" className="Label justify-start text-[#5f6f62] text-[10px] font-normal font-['Inter']">of your day</div>
          </div>
        </div>
        <div data-layer="Progress message" data-node-id="2-1365" className="ProgressMessage flex-1 inline-flex flex-col justify-start items-start gap-2.5 overflow-hidden">
          <div data-layer="Eyebrow" data-node-id="2-1366" className="Eyebrow justify-start text-[#427356] text-[10px] font-semibold font-['Inter']">LITTLE WINS ADD UP</div>
          <div data-layer="Heading" data-node-id="2-1367" className="Heading self-stretch justify-start text-[#293d32] text-[25px] font-normal font-['Lora']">You’re making space for you.</div>
          <div data-layer="Description" data-node-id="2-1368" className="Description self-stretch justify-start text-[#5f6f62] text-[13px] font-normal font-['Inter']">3 of 6 habits complete. A few small steps, and you’re already moving forward.</div>
        </div>
      </div>
      <div data-layer="Growth summary" data-node-id="2-1369" className="GrowthSummary w-[412px] self-stretch p-6 bg-white rounded-[20px] outline outline-1 outline-offset-[-1px] outline-[#e7ebe3] flex justify-start items-center gap-6 overflow-hidden">
        <div data-layer="Consistency" data-node-id="2-1370" className="Consistency flex-1 inline-flex flex-col justify-start items-start gap-2.5 overflow-hidden">
          <div data-layer="sprout" data-node-id="2-1572" className="Sprout w-5 h-5 relative overflow-hidden">
            <img data-layer="Vector" data-node-id="2-1573" className="Vector w-[13.33px] h-[15px] left-[3.33px] top-[2.50px] absolute" src="/figma-assets/2-1573.svg" />
          </div>
          <div data-layer="Value" data-node-id="2-1372" className="Value justify-start text-[#293d32] text-[29px] font-normal font-['Lora']">7 days</div>
          <div data-layer="Label" data-node-id="2-1373" className="Label justify-start text-[#5f6f62] text-xs font-normal font-['Inter']">showing up for you</div>
        </div>
        <div data-layer="Divider" data-node-id="2-1374" className="Divider w-px h-20 bg-[#e7ebe3]" />
        <div data-layer="Monthly progress" data-node-id="2-1375" className="MonthlyProgress flex-1 inline-flex flex-col justify-start items-start gap-2.5 overflow-hidden">
          <div data-layer="circle-check" data-node-id="2-1575" className="CircleCheck w-5 h-5 relative overflow-hidden">
            <img data-layer="Vector" data-node-id="2-1576" className="Vector w-[16.67px] h-[16.67px] left-[1.67px] top-[1.67px] absolute" src="/figma-assets/2-1576.svg" />
          </div>
          <div data-layer="Value" data-node-id="2-1377" className="Value justify-start text-[#293d32] text-[29px] font-normal font-['Lora']">42</div>
          <div data-layer="Label" data-node-id="2-1378" className="Label justify-start text-[#5f6f62] text-xs font-normal font-['Inter']">little wins this month</div>
        </div>
      </div>
    </div>
    <div data-layer="Habits and insights" data-node-id="2-1379" className="HabitsAndInsights self-stretch inline-flex justify-start items-start gap-6 overflow-hidden">
      <div data-layer="Today’s habits" data-node-id="2-1380" className="TodaySHabits flex-1 px-6 pt-[23px] pb-4 bg-white rounded-[20px] outline outline-1 outline-offset-[-1px] outline-[#e7ebe3] inline-flex flex-col justify-start items-start gap-3.5 overflow-hidden">
        <div data-layer="Section heading" data-node-id="2-1381" className="SectionHeading self-stretch inline-flex justify-between items-center overflow-hidden">
          <div data-layer="Title and count" data-node-id="2-1382" className="TitleAndCount flex justify-start items-center gap-2.5 overflow-hidden">
            <div data-layer="Title" data-node-id="2-1383" className="Title justify-start text-[#293d32] text-[22px] font-normal font-['Lora']">Today’s habits</div>
            <div data-layer="Count" data-node-id="2-1384" className="Count justify-start text-[#7b857b] text-xs font-normal font-['Inter']">6</div>
          </div>
          <div data-layer="Habit filter" data-node-id="2-1385" className="HabitFilter flex justify-start items-center gap-[7px] overflow-hidden">
            <div data-layer="Selection" data-node-id="2-1386" className="Selection justify-start text-[#5f6f62] text-xs font-normal font-['Inter']">All habits</div>
            <div data-layer="chevron-down" data-node-id="2-1578" className="ChevronDown w-3.5 h-3.5 relative overflow-hidden">
              <img data-layer="Vector" data-node-id="2-1579" className="Vector w-[7px] h-[3.50px] left-[3.50px] top-[5.25px] absolute" src="/figma-assets/2-1579.svg" />
            </div>
          </div>
        </div>
        <div data-layer="Habit view tabs" data-node-id="2-1388" className="HabitViewTabs self-stretch border-b border-[#e7ebe3] inline-flex justify-start items-start gap-5 overflow-hidden">
          <div data-layer="Active tab" data-node-id="2-1389" className="ActiveTab py-2.5 border-b-2 border-[#427356] flex justify-start items-start overflow-hidden">
            <div data-layer="Label" data-node-id="2-1390" className="Label justify-start text-[#427356] text-xs font-medium font-['Inter']">Today</div>
          </div>
          <div data-layer="Upcoming tab" data-node-id="2-1391" className="UpcomingTab py-2.5 flex justify-start items-start overflow-hidden">
            <div data-layer="Label" data-node-id="2-1392" className="Label justify-start text-[#7b857b] text-xs font-normal font-['Inter']">Upcoming</div>
          </div>
        </div>
        <div data-layer="Habit list" data-node-id="2-1393" className="HabitList self-stretch flex flex-col justify-start items-start overflow-hidden">
          <div data-layer="Habit" data-node-id="2-1394" className="Habit self-stretch h-[76px] border-b border-[#e7ebe3] inline-flex justify-start items-center gap-3.5 overflow-hidden">
            <div data-layer="Completion control" data-node-id="2-1395" className="CompletionControl w-6 h-6 bg-[#427356] rounded-lg outline outline-[1.50px] outline-offset-[-1.50px] outline-[#427356] flex justify-center items-center overflow-hidden">
              <div data-layer="check" data-node-id="2-1581" className="Check w-[15px] h-[15px] relative overflow-hidden">
                <img data-layer="Vector" data-node-id="2-1582" className="Vector w-2.5 h-[6.87px] left-[2.50px] top-[3.75px] absolute" src="/figma-assets/2-1582.svg" />
              </div>
            </div>
            <div data-layer="Habit symbol" data-node-id="2-1397" className="HabitSymbol w-[42px] h-[42px] bg-[#f1f5ed] rounded-[14px] flex justify-center items-center overflow-hidden">
              <div data-layer="wind" data-node-id="2-1584" className="Wind w-5 h-5 relative overflow-hidden">
                <img data-layer="Vector" data-node-id="2-1585" className="Vector w-[16.67px] h-[13.33px] left-[1.67px] top-[3.33px] absolute" src="/figma-assets/2-1585.svg" />
              </div>
            </div>
            <div data-layer="Habit details" data-node-id="2-1399" className="HabitDetails flex-1 inline-flex flex-col justify-start items-start gap-1.5 overflow-hidden">
              <div data-layer="Title" data-node-id="2-1400" className="Title self-stretch justify-start text-[#5f6f62] text-sm font-medium font-['Inter']">A moment of stillness</div>
              <div data-layer="Goal" data-node-id="2-1401" className="Goal self-stretch justify-start text-[#7b857b] text-xs font-normal font-['Inter']">Meditate · 10 minutes</div>
            </div>
            <div data-layer="Habit category" data-node-id="2-1402" className="HabitCategory px-[9px] py-[5px] bg-[#f1f5ed] rounded-[100px] flex justify-start items-start overflow-hidden">
              <div data-layer="Category" data-node-id="2-1403" className="Category justify-start text-[#5f6f62] text-[10px] font-normal font-['Inter']">Mind</div>
            </div>
            <div data-layer="ellipsis" data-node-id="2-1587" className="Ellipsis w-4 h-4 relative overflow-hidden">
              <img data-layer="Vector" data-node-id="2-1588" className="Vector w-[10.67px] h-[1.33px] left-[2.67px] top-[7.33px] absolute" src="/figma-assets/2-1588.svg" />
            </div>
          </div>
          <div data-layer="Habit" data-node-id="2-1405" className="Habit self-stretch h-[76px] border-b border-[#e7ebe3] inline-flex justify-start items-center gap-3.5 overflow-hidden">
            <div data-layer="Completion control" data-node-id="2-1406" className="CompletionControl w-6 h-6 bg-[#427356] rounded-lg outline outline-[1.50px] outline-offset-[-1.50px] outline-[#427356] flex justify-center items-center overflow-hidden">
              <div data-layer="check" data-node-id="2-1590" className="Check w-[15px] h-[15px] relative overflow-hidden">
                <img data-layer="Vector" data-node-id="2-1591" className="Vector w-2.5 h-[6.87px] left-[2.50px] top-[3.75px] absolute" src="/figma-assets/2-1591.svg" />
              </div>
            </div>
            <div data-layer="Habit symbol" data-node-id="2-1408" className="HabitSymbol w-[42px] h-[42px] bg-[#f1f5ed] rounded-[14px] flex justify-center items-center overflow-hidden">
              <div data-layer="person-standing" data-node-id="2-1593" className="PersonStanding w-5 h-5 relative overflow-hidden">
                <img data-layer="Vector" data-node-id="2-1594" className="Vector w-2.5 h-[13.33px] left-[5px] top-[3.33px] absolute" src="/figma-assets/2-1594.svg" />
              </div>
            </div>
            <div data-layer="Habit details" data-node-id="2-1410" className="HabitDetails flex-1 inline-flex flex-col justify-start items-start gap-1.5 overflow-hidden">
              <div data-layer="Title" data-node-id="2-1411" className="Title self-stretch justify-start text-[#5f6f62] text-sm font-medium font-['Inter']">Move with the morning</div>
              <div data-layer="Goal" data-node-id="2-1412" className="Goal self-stretch justify-start text-[#7b857b] text-xs font-normal font-['Inter']">Gentle stretching · 15 minutes</div>
            </div>
            <div data-layer="Habit category" data-node-id="2-1413" className="HabitCategory px-[9px] py-[5px] bg-[#f1f5ed] rounded-[100px] flex justify-start items-start overflow-hidden">
              <div data-layer="Category" data-node-id="2-1414" className="Category justify-start text-[#5f6f62] text-[10px] font-normal font-['Inter']">Body</div>
            </div>
            <div data-layer="ellipsis" data-node-id="2-1596" className="Ellipsis w-4 h-4 relative overflow-hidden">
              <img data-layer="Vector" data-node-id="2-1597" className="Vector w-[10.67px] h-[1.33px] left-[2.67px] top-[7.33px] absolute" src="/figma-assets/2-1597.svg" />
            </div>
          </div>
          <div data-layer="Habit" data-node-id="2-1416" className="Habit self-stretch h-[76px] border-b border-[#e7ebe3] inline-flex justify-start items-center gap-3.5 overflow-hidden">
            <div data-layer="Completion control" data-node-id="2-1417" className="CompletionControl w-6 h-6 bg-[#427356] rounded-lg outline outline-[1.50px] outline-offset-[-1.50px] outline-[#427356] flex justify-center items-center overflow-hidden">
              <div data-layer="check" data-node-id="2-1599" className="Check w-[15px] h-[15px] relative overflow-hidden">
                <img data-layer="Vector" data-node-id="2-1600" className="Vector w-2.5 h-[6.87px] left-[2.50px] top-[3.75px] absolute" src="/figma-assets/2-1600.svg" />
              </div>
            </div>
            <div data-layer="Habit symbol" data-node-id="2-1419" className="HabitSymbol w-[42px] h-[42px] bg-[#f1f5ed] rounded-[14px] flex justify-center items-center overflow-hidden">
              <div data-layer="book-open" data-node-id="2-1602" className="BookOpen w-5 h-5 relative overflow-hidden">
                <img data-layer="Vector" data-node-id="2-1603" className="Vector w-[16.67px] h-[15px] left-[1.67px] top-[2.50px] absolute" src="/figma-assets/2-1603.svg" />
              </div>
            </div>
            <div data-layer="Habit details" data-node-id="2-1421" className="HabitDetails flex-1 inline-flex flex-col justify-start items-start gap-1.5 overflow-hidden">
              <div data-layer="Title" data-node-id="2-1422" className="Title self-stretch justify-start text-[#5f6f62] text-sm font-medium font-['Inter']">Nourish your mind</div>
              <div data-layer="Goal" data-node-id="2-1423" className="Goal self-stretch justify-start text-[#7b857b] text-xs font-normal font-['Inter']">Read · 10 pages</div>
            </div>
            <div data-layer="Habit category" data-node-id="2-1424" className="HabitCategory px-[9px] py-[5px] bg-[#f1f5ed] rounded-[100px] flex justify-start items-start overflow-hidden">
              <div data-layer="Category" data-node-id="2-1425" className="Category justify-start text-[#5f6f62] text-[10px] font-normal font-['Inter']">Mind</div>
            </div>
            <div data-layer="ellipsis" data-node-id="2-1605" className="Ellipsis w-4 h-4 relative overflow-hidden">
              <img data-layer="Vector" data-node-id="2-1606" className="Vector w-[10.67px] h-[1.33px] left-[2.67px] top-[7.33px] absolute" src="/figma-assets/2-1606.svg" />
            </div>
          </div>
          <div data-layer="Habit" data-node-id="2-1427" className="Habit self-stretch h-[76px] border-b border-[#e7ebe3] inline-flex justify-start items-center gap-3.5 overflow-hidden">
            <div data-layer="Completion control" data-node-id="2-1428" className="CompletionControl w-6 h-6 bg-white rounded-lg outline outline-[1.50px] outline-offset-[-1.50px] outline-[#d7e2ce] flex justify-center items-center" />
            <div data-layer="Habit symbol" data-node-id="2-1429" className="HabitSymbol w-[42px] h-[42px] bg-[#f5f1e7] rounded-[14px] flex justify-center items-center overflow-hidden">
              <div data-layer="droplet" data-node-id="2-1608" className="Droplet w-5 h-5 relative overflow-hidden">
                <img data-layer="Vector" data-node-id="2-1609" className="Vector w-[11.67px] h-[15.83px] left-[4.17px] top-[2.50px] absolute" src="/figma-assets/2-1609.svg" />
              </div>
            </div>
            <div data-layer="Habit details" data-node-id="2-1431" className="HabitDetails flex-1 inline-flex flex-col justify-start items-start gap-1.5 overflow-hidden">
              <div data-layer="Title" data-node-id="2-1432" className="Title self-stretch justify-start text-[#293d32] text-sm font-medium font-['Inter']">Stay hydrated</div>
              <div data-layer="Goal" data-node-id="2-1433" className="Goal self-stretch justify-start text-[#7b857b] text-xs font-normal font-['Inter']">Drink water · 8 glasses</div>
            </div>
            <div data-layer="Increment habit" data-node-id="2-1434" className="IncrementHabit flex justify-start items-center gap-[9px] overflow-hidden">
              <div data-layer="Current amount" data-node-id="2-1435" className="CurrentAmount justify-start text-[#427356] text-xs font-normal font-['Inter']">4 / 8</div>
              <div data-layer="Add glass" data-node-id="2-1436" className="AddGlass w-[27px] h-[27px] rounded-lg outline outline-1 outline-offset-[-1px] outline-[#d7e2ce] flex justify-center items-center overflow-hidden">
                <div data-layer="plus" data-node-id="2-1611" className="Plus w-3.5 h-3.5 relative overflow-hidden">
                  <img data-layer="Vector" data-node-id="2-1612" className="Vector w-[8.17px] h-[8.17px] left-[2.92px] top-[2.92px] absolute" src="/figma-assets/2-1612.svg" />
                </div>
              </div>
            </div>
            <div data-layer="ellipsis" data-node-id="2-1614" className="Ellipsis w-4 h-4 relative overflow-hidden">
              <img data-layer="Vector" data-node-id="2-1615" className="Vector w-[10.67px] h-[1.33px] left-[2.67px] top-[7.33px] absolute" src="/figma-assets/2-1615.svg" />
            </div>
          </div>
          <div data-layer="Habit" data-node-id="2-1439" className="Habit self-stretch h-[76px] border-b border-[#e7ebe3] inline-flex justify-start items-center gap-3.5 overflow-hidden">
            <div data-layer="Completion control" data-node-id="2-1440" className="CompletionControl w-6 h-6 bg-white rounded-lg outline outline-[1.50px] outline-offset-[-1.50px] outline-[#d7e2ce] flex justify-center items-center" />
            <div data-layer="Habit symbol" data-node-id="2-1441" className="HabitSymbol w-[42px] h-[42px] bg-[#f5f1e7] rounded-[14px] flex justify-center items-center overflow-hidden">
              <div data-layer="trees" data-node-id="2-1617" className="Trees w-5 h-5 relative overflow-hidden">
                <img data-layer="Vector" data-node-id="2-1618" className="Vector w-4 h-[15.83px] left-[1.73px] top-[2.50px] absolute" src="/figma-assets/2-1618.svg" />
              </div>
            </div>
            <div data-layer="Habit details" data-node-id="2-1443" className="HabitDetails flex-1 inline-flex flex-col justify-start items-start gap-1.5 overflow-hidden">
              <div data-layer="Title" data-node-id="2-1444" className="Title self-stretch justify-start text-[#293d32] text-sm font-medium font-['Inter']">A little fresh air</div>
              <div data-layer="Goal" data-node-id="2-1445" className="Goal self-stretch justify-start text-[#7b857b] text-xs font-normal font-['Inter']">Walk outside · 20 minutes</div>
            </div>
            <div data-layer="Habit category" data-node-id="2-1446" className="HabitCategory px-[9px] py-[5px] bg-[#f1f5ed] rounded-[100px] flex justify-start items-start overflow-hidden">
              <div data-layer="Category" data-node-id="2-1447" className="Category justify-start text-[#5f6f62] text-[10px] font-normal font-['Inter']">Body</div>
            </div>
            <div data-layer="ellipsis" data-node-id="2-1620" className="Ellipsis w-4 h-4 relative overflow-hidden">
              <img data-layer="Vector" data-node-id="2-1621" className="Vector w-[10.67px] h-[1.33px] left-[2.67px] top-[7.33px] absolute" src="/figma-assets/2-1621.svg" />
            </div>
          </div>
          <div data-layer="Habit" data-node-id="2-1449" className="Habit self-stretch h-[76px] border-b border-[#e7ebe3] inline-flex justify-start items-center gap-3.5 overflow-hidden">
            <div data-layer="Completion control" data-node-id="2-1450" className="CompletionControl w-6 h-6 bg-white rounded-lg outline outline-[1.50px] outline-offset-[-1.50px] outline-[#d7e2ce] flex justify-center items-center" />
            <div data-layer="Habit symbol" data-node-id="2-1451" className="HabitSymbol w-[42px] h-[42px] bg-[#f5f1e7] rounded-[14px] flex justify-center items-center overflow-hidden">
              <div data-layer="notebook-pen" data-node-id="2-1623" className="NotebookPen w-5 h-5 relative overflow-hidden">
                <img data-layer="Vector" data-node-id="2-1624" className="Vector w-[16.67px] h-[16.67px] left-[1.67px] top-[1.67px] absolute" src="/figma-assets/2-1624.svg" />
              </div>
            </div>
            <div data-layer="Habit details" data-node-id="2-1453" className="HabitDetails flex-1 inline-flex flex-col justify-start items-start gap-1.5 overflow-hidden">
              <div data-layer="Title" data-node-id="2-1454" className="Title self-stretch justify-start text-[#293d32] text-sm font-medium font-['Inter']">End on a grateful note</div>
              <div data-layer="Goal" data-node-id="2-1455" className="Goal self-stretch justify-start text-[#7b857b] text-xs font-normal font-['Inter']">Write down 3 good things</div>
            </div>
            <div data-layer="Habit category" data-node-id="2-1456" className="HabitCategory px-[9px] py-[5px] bg-[#f1f5ed] rounded-[100px] flex justify-start items-start overflow-hidden">
              <div data-layer="Category" data-node-id="2-1457" className="Category justify-start text-[#5f6f62] text-[10px] font-normal font-['Inter']">Mind</div>
            </div>
            <div data-layer="ellipsis" data-node-id="2-1626" className="Ellipsis w-4 h-4 relative overflow-hidden">
              <img data-layer="Vector" data-node-id="2-1627" className="Vector w-[10.67px] h-[1.33px] left-[2.67px] top-[7.33px] absolute" src="/figma-assets/2-1627.svg" />
            </div>
          </div>
        </div>
        <div data-layer="Add habit" data-node-id="2-1459" className="AddHabit self-stretch py-[3px] inline-flex justify-center items-center gap-[7px] overflow-hidden">
          <div data-layer="plus" data-node-id="2-1629" className="Plus w-[15px] h-[15px] relative overflow-hidden">
            <img data-layer="Vector" data-node-id="2-1630" className="Vector w-[8.75px] h-[8.75px] left-[3.12px] top-[3.12px] absolute" src="/figma-assets/2-1630.svg" />
          </div>
          <div data-layer="Label" data-node-id="2-1461" className="Label justify-start text-[#427356] text-xs font-normal font-['Inter']">Plant a new habit</div>
        </div>
      </div>
      <div data-layer="Weekly perspective" data-node-id="2-1462" className="WeeklyPerspective w-[412px] inline-flex flex-col justify-start items-start gap-5 overflow-hidden">
        <div data-layer="Weekly overview" data-node-id="2-1463" className="WeeklyOverview self-stretch p-6 bg-white rounded-[20px] outline outline-1 outline-offset-[-1px] outline-[#e7ebe3] flex flex-col justify-start items-start gap-5 overflow-hidden">
          <div data-layer="Section heading" data-node-id="2-1464" className="SectionHeading self-stretch inline-flex justify-between items-center overflow-hidden">
            <div data-layer="Title" data-node-id="2-1465" className="Title justify-start text-[#293d32] text-[21px] font-normal font-['Lora']">Your week in bloom</div>
            <div data-layer="arrow-up-right" data-node-id="2-1632" className="ArrowUpRight w-[17px] h-[17px] relative overflow-hidden">
              <img data-layer="Vector" data-node-id="2-1633" className="Vector w-[7.08px] h-[7.08px] left-[4.96px] top-[4.96px] absolute" src="/figma-assets/2-1633.svg" />
            </div>
          </div>
          <div data-layer="Week range" data-node-id="2-1467" className="WeekRange self-stretch inline-flex justify-between items-center overflow-hidden">
            <div data-layer="Date range" data-node-id="2-1468" className="DateRange justify-start text-[#7b857b] text-xs font-normal font-['Inter']">October 21 – 27</div>
            <div data-layer="Chart key" data-node-id="2-1469" className="ChartKey flex justify-start items-center gap-[5px] overflow-hidden">
              <div data-layer="Legend marker" data-node-id="2-1470" className="LegendMarker w-[5px] h-[5px] bg-[#427356] rounded-full" />
              <div data-layer="Label" data-node-id="2-1471" className="Label justify-start text-[#5f6f62] text-[10px] font-normal font-['Inter']">Habits completed</div>
            </div>
          </div>
          <div data-layer="Weekly chart" data-node-id="2-1472" className="WeeklyChart self-stretch inline-flex justify-start items-end gap-[11px] overflow-hidden">
            <div data-layer="Daily progress" data-node-id="2-1473" className="DailyProgress flex-1 inline-flex flex-col justify-start items-center gap-2 overflow-hidden">
              <div data-layer="Progress bar" data-node-id="2-1474" className="ProgressBar w-[29px] h-[108px] relative bg-[#f1f5ed] rounded-[7px] flex flex-col justify-end items-center overflow-hidden">
                <div data-layer="Completed habits" data-node-id="2-1475" className="CompletedHabits w-[29px] h-[72px] bg-[#d7e2ce] rounded-[7px]" />
                <div data-layer="Habit count" data-node-id="2-1476" className="HabitCount left-[11px] top-[87px] absolute justify-start text-[#345c45] text-[10px] font-normal font-['Inter']">4</div>
              </div>
              <div data-layer="Day" data-node-id="2-1477" className="Day justify-start text-[#7b857b] text-[10px] font-normal font-['Inter']">Wed</div>
              <div data-layer="Date indicator" data-node-id="2-1478" className="DateIndicator w-[23px] h-[23px] bg-black/0 rounded-[100px] inline-flex justify-center items-center overflow-hidden">
                <div data-layer="Date" data-node-id="2-1479" className="Date justify-start text-[#7b857b] text-[10px] font-normal font-['Inter']">21</div>
              </div>
            </div>
            <div data-layer="Daily progress" data-node-id="2-1480" className="DailyProgress flex-1 inline-flex flex-col justify-start items-center gap-2 overflow-hidden">
              <div data-layer="Progress bar" data-node-id="2-1481" className="ProgressBar w-[29px] h-[108px] relative bg-[#f1f5ed] rounded-[7px] flex flex-col justify-end items-center overflow-hidden">
                <div data-layer="Completed habits" data-node-id="2-1482" className="CompletedHabits w-[29px] h-[90px] bg-[#d7e2ce] rounded-[7px]" />
                <div data-layer="Habit count" data-node-id="2-1483" className="HabitCount left-[11px] top-[87px] absolute justify-start text-[#345c45] text-[10px] font-normal font-['Inter']">5</div>
              </div>
              <div data-layer="Day" data-node-id="2-1484" className="Day justify-start text-[#7b857b] text-[10px] font-normal font-['Inter']">Thu</div>
              <div data-layer="Date indicator" data-node-id="2-1485" className="DateIndicator w-[23px] h-[23px] bg-black/0 rounded-[100px] inline-flex justify-center items-center overflow-hidden">
                <div data-layer="Date" data-node-id="2-1486" className="Date justify-start text-[#7b857b] text-[10px] font-normal font-['Inter']">22</div>
              </div>
            </div>
            <div data-layer="Daily progress" data-node-id="2-1487" className="DailyProgress flex-1 inline-flex flex-col justify-start items-center gap-2 overflow-hidden">
              <div data-layer="Progress bar" data-node-id="2-1488" className="ProgressBar w-[29px] h-[108px] relative bg-[#f1f5ed] rounded-[7px] flex flex-col justify-end items-center overflow-hidden">
                <div data-layer="Completed habits" data-node-id="2-1489" className="CompletedHabits w-[29px] h-[54px] bg-[#d7e2ce] rounded-[7px]" />
                <div data-layer="Habit count" data-node-id="2-1490" className="HabitCount left-[11px] top-[87px] absolute justify-start text-[#345c45] text-[10px] font-normal font-['Inter']">3</div>
              </div>
              <div data-layer="Day" data-node-id="2-1491" className="Day justify-start text-[#7b857b] text-[10px] font-normal font-['Inter']">Fri</div>
              <div data-layer="Date indicator" data-node-id="2-1492" className="DateIndicator w-[23px] h-[23px] bg-black/0 rounded-[100px] inline-flex justify-center items-center overflow-hidden">
                <div data-layer="Date" data-node-id="2-1493" className="Date justify-start text-[#7b857b] text-[10px] font-normal font-['Inter']">23</div>
              </div>
            </div>
            <div data-layer="Daily progress" data-node-id="2-1494" className="DailyProgress flex-1 inline-flex flex-col justify-start items-center gap-2 overflow-hidden">
              <div data-layer="Progress bar" data-node-id="2-1495" className="ProgressBar w-[29px] h-[108px] relative bg-[#f1f5ed] rounded-[7px] flex flex-col justify-end items-center overflow-hidden">
                <div data-layer="Completed habits" data-node-id="2-1496" className="CompletedHabits w-[29px] h-[108px] bg-[#d7e2ce] rounded-[7px]" />
                <div data-layer="Habit count" data-node-id="2-1497" className="HabitCount left-[11px] top-[87px] absolute justify-start text-[#345c45] text-[10px] font-normal font-['Inter']">6</div>
              </div>
              <div data-layer="Day" data-node-id="2-1498" className="Day justify-start text-[#7b857b] text-[10px] font-normal font-['Inter']">Sat</div>
              <div data-layer="Date indicator" data-node-id="2-1499" className="DateIndicator w-[23px] h-[23px] bg-black/0 rounded-[100px] inline-flex justify-center items-center overflow-hidden">
                <div data-layer="Date" data-node-id="2-1500" className="Date justify-start text-[#7b857b] text-[10px] font-normal font-['Inter']">24</div>
              </div>
            </div>
            <div data-layer="Daily progress" data-node-id="2-1501" className="DailyProgress flex-1 inline-flex flex-col justify-start items-center gap-2 overflow-hidden">
              <div data-layer="Progress bar" data-node-id="2-1502" className="ProgressBar w-[29px] h-[108px] relative bg-[#f1f5ed] rounded-[7px] flex flex-col justify-end items-center overflow-hidden">
                <div data-layer="Completed habits" data-node-id="2-1503" className="CompletedHabits w-[29px] h-[72px] bg-[#d7e2ce] rounded-[7px]" />
                <div data-layer="Habit count" data-node-id="2-1504" className="HabitCount left-[11px] top-[87px] absolute justify-start text-[#345c45] text-[10px] font-normal font-['Inter']">4</div>
              </div>
              <div data-layer="Day" data-node-id="2-1505" className="Day justify-start text-[#7b857b] text-[10px] font-normal font-['Inter']">Sun</div>
              <div data-layer="Date indicator" data-node-id="2-1506" className="DateIndicator w-[23px] h-[23px] bg-black/0 rounded-[100px] inline-flex justify-center items-center overflow-hidden">
                <div data-layer="Date" data-node-id="2-1507" className="Date justify-start text-[#7b857b] text-[10px] font-normal font-['Inter']">25</div>
              </div>
            </div>
            <div data-layer="Daily progress" data-node-id="2-1508" className="DailyProgress flex-1 inline-flex flex-col justify-start items-center gap-2 overflow-hidden">
              <div data-layer="Progress bar" data-node-id="2-1509" className="ProgressBar w-[29px] h-[108px] relative bg-[#f1f5ed] rounded-[7px] flex flex-col justify-end items-center overflow-hidden">
                <div data-layer="Completed habits" data-node-id="2-1510" className="CompletedHabits w-[29px] h-[90px] bg-[#d7e2ce] rounded-[7px]" />
                <div data-layer="Habit count" data-node-id="2-1511" className="HabitCount left-[11px] top-[87px] absolute justify-start text-[#345c45] text-[10px] font-normal font-['Inter']">5</div>
              </div>
              <div data-layer="Day" data-node-id="2-1512" className="Day justify-start text-[#7b857b] text-[10px] font-normal font-['Inter']">Mon</div>
              <div data-layer="Date indicator" data-node-id="2-1513" className="DateIndicator w-[23px] h-[23px] bg-black/0 rounded-[100px] inline-flex justify-center items-center overflow-hidden">
                <div data-layer="Date" data-node-id="2-1514" className="Date justify-start text-[#7b857b] text-[10px] font-normal font-['Inter']">26</div>
              </div>
            </div>
            <div data-layer="Daily progress" data-node-id="2-1515" className="DailyProgress flex-1 inline-flex flex-col justify-start items-center gap-2 overflow-hidden">
              <div data-layer="Progress bar" data-node-id="2-1516" className="ProgressBar w-[29px] h-[108px] relative bg-[#f1f5ed] rounded-[7px] flex flex-col justify-end items-center overflow-hidden">
                <div data-layer="Completed habits" data-node-id="2-1517" className="CompletedHabits w-[29px] h-[54px] bg-[#427356] rounded-[7px]" />
                <div data-layer="Habit count" data-node-id="2-1518" className="HabitCount left-[11px] top-[87px] absolute justify-start text-white text-[10px] font-normal font-['Inter']">3</div>
              </div>
              <div data-layer="Day" data-node-id="2-1519" className="Day justify-start text-[#427356] text-[10px] font-semibold font-['Inter']">Tue</div>
              <div data-layer="Date indicator" data-node-id="2-1520" className="DateIndicator w-[23px] h-[23px] bg-[#e7eedf] rounded-[100px] inline-flex justify-center items-center overflow-hidden">
                <div data-layer="Date" data-node-id="2-1521" className="Date justify-start text-[#427356] text-[10px] font-normal font-['Inter']">27</div>
              </div>
            </div>
          </div>
          <div data-layer="Weekly insight" data-node-id="2-1522" className="WeeklyInsight self-stretch pt-[15px] border-t border-[#e7ebe3] inline-flex justify-start items-center gap-[9px] overflow-hidden">
            <div data-layer="leaf" data-node-id="2-1635" className="Leaf w-4 h-4 relative overflow-hidden">
              <img data-layer="Vector" data-node-id="2-1636" className="Vector w-[12.67px] h-[12.67px] left-[1.33px] top-[1.33px] absolute" src="/figma-assets/2-1636.svg" />
            </div>
            <div data-layer="Message" data-node-id="2-1524" className="Message flex-1 justify-start text-[#5f6f62] text-xs font-normal font-['Inter']">30 small wins. Every one counts.</div>
          </div>
        </div>
        <div data-layer="Moment of reflection" data-node-id="2-1525" className="MomentOfReflection self-stretch h-[266px] p-6 relative bg-[#f5f1e7] rounded-[20px] flex flex-col justify-start items-start gap-[15px] overflow-hidden">
          <img data-layer="Botanical study" data-node-id="2-1526" className="BotanicalStudy w-[177px] h-[266px] left-[235px] top-0 absolute" src="/figma-assets/2-1526.webp" />
          <div data-layer="Reflection label" data-node-id="2-1527" className="ReflectionLabel inline-flex justify-start items-center gap-[7px] overflow-hidden">
            <div data-layer="sun" data-node-id="2-1638" className="Sun w-[15px] h-[15px] relative overflow-hidden">
              <img data-layer="Vector" data-node-id="2-1639" className="Vector w-[12.50px] h-[12.50px] left-[1.25px] top-[1.25px] absolute" src="/figma-assets/2-1639.svg" />
            </div>
            <div data-layer="Eyebrow" data-node-id="2-1529" className="Eyebrow justify-start text-[#5f6f62] text-[10px] font-medium font-['Inter']">A MOMENT FOR YOU</div>
          </div>
          <div data-layer="Prompt" data-node-id="2-1530" className="Prompt w-[220px] justify-start text-[#293d32] text-2xl font-normal font-['Lora']">How are you feeling today?</div>
          <div data-layer="Supporting message" data-node-id="2-1531" className="SupportingMessage w-[220px] justify-start text-[#5f6f62] text-xs font-normal font-['Inter']">Pause, take a breath, and check in with yourself.</div>
          <div data-layer="Open journal" data-node-id="2-1532" className="OpenJournal pt-[5px] inline-flex justify-start items-center gap-2 overflow-hidden">
            <div data-layer="Label" data-node-id="2-1533" className="Label justify-start text-[#427356] text-xs font-medium font-['Inter']">Write a little</div>
            <div data-layer="arrow-right" data-node-id="2-1641" className="ArrowRight w-3.5 h-3.5 relative overflow-hidden">
              <img data-layer="Vector" data-node-id="2-1642" className="Vector w-[8.17px] h-[8.17px] left-[2.92px] top-[2.92px] absolute" src="/figma-assets/2-1642.svg" />
            </div>
          </div>
        </div>
      </div>
    </div>
    <div data-layer="Daily encouragement" data-node-id="2-1535" className="DailyEncouragement self-stretch inline-flex justify-between items-start overflow-hidden">
      <div data-layer="Encouragement" data-node-id="2-1536" className="Encouragement justify-start text-[#7b857b] text-xs font-normal font-['Inter']">You don’t have to do it all. Just keep coming back.</div>
      <div data-layer="Save status" data-node-id="2-1537" className="SaveStatus justify-start text-[#7b857b] text-xs font-normal font-['Inter']">All changes saved</div>
    </div>
  </div>
</div>
  )
}
