import { startLogin } from "@/const";
import { useAuth } from "@/_core/hooks/useAuth";
import { trpc } from "@/lib/trpc";
import { AIChatBox, type Message } from "@/components/AIChatBox";
import { AIGoalPlanner, GoalPlansSection } from "@/components/GoalPlanning";
import type { GoalPlanDraft, SavedGoal } from "@shared/goalPlan";
import { Dialog, DialogContent, DialogDescription, DialogTitle } from "@/components/ui/dialog";
import {
  Bell,
  BellRing,
  CalendarDays,
  Check,
  ChevronRight,
  CircleHelp,
  Clock3,
  Dumbbell,
  Flame,
  HeartPulse,
  Home as HomeIcon,
  LogOut,
  Menu,
  MessageCircle,
  MoreHorizontal,
  Pause,
  Play,
  Plus,
  RotateCcw,
  Search,
  Settings,
  Sparkles,
  Target,
  TimerReset,
  Trophy,
  UserRound,
  Wifi,
  WifiOff,
  X,
  Zap,
  Utensils,
} from "lucide-react";
import { useEffect, useMemo, useRef, useState } from "react";
import FigmaDashboard from "./FigmaDashboard";
import DietView, { type DietLogEntry } from "./DietView";
import {
  Bar,
  BarChart,
  CartesianGrid,
  Cell,
  Line,
  LineChart,
  Pie,
  PieChart,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from "recharts";

export type Habit = {
  id: string;
  name: string;
  emoji: string;
  category: string;
  frequency: string;
  goal: string;
  streak: number;
  bestStreak: number;
  completedToday: boolean;
  reminder: string;
  accent: string;
};

export type Workout = {
  id: string;
  name: string;
  focus: string;
  duration: number;
  exercises: string[];
  completed: boolean;
  accent: string;
};

export type AppData = {
  habits: Habit[];
  workouts: Workout[];
  goals?: SavedGoal[];
  activity: { day: string; minutes: number; habits: number }[];
  settings: { notifications: boolean; weekStarts: string; reducedMotion: boolean };
  lastActive: string;
  dietLog?: DietLogEntry[];
};

type Tab = "overview" | "habits" | "workouts" | "diet" | "progress" | "settings";

const todayKey = new Date().toISOString().slice(0, 10);
const STORAGE_KEY = "streakly-app-data-v1";
const chartColors = ["#6e6af6", "#ff9f68", "#59c6a8", "#f6c85f"];

const starterData: AppData = {
  habits: [
    { id: "water", name: "Drink water", emoji: "💧", category: "Body", frequency: "Daily", goal: "8 glasses", streak: 12, bestStreak: 21, completedToday: true, reminder: "8:30 AM", accent: "blue" },
    { id: "read", name: "Read 10 pages", emoji: "📖", category: "Mind", frequency: "Daily", goal: "10 pages", streak: 8, bestStreak: 14, completedToday: true, reminder: "9:00 PM", accent: "orange" },
    { id: "stretch", name: "Morning stretch", emoji: "🧘", category: "Body", frequency: "Weekdays", goal: "5 minutes", streak: 5, bestStreak: 9, completedToday: false, reminder: "7:15 AM", accent: "mint" },
    { id: "walk", name: "Walk outside", emoji: "🌿", category: "Mind", frequency: "3× / week", goal: "20 minutes", streak: 3, bestStreak: 11, completedToday: false, reminder: "6:00 PM", accent: "yellow" },
  ],
  workouts: [
    { id: "upper", name: "Upper body power", focus: "Strength", duration: 28, exercises: ["Push-ups", "Bent-over row", "Shoulder press", "Plank"], completed: false, accent: "purple" },
    { id: "run", name: "Easy run", focus: "Cardio", duration: 32, exercises: ["Warm-up walk", "Easy pace", "Cool-down"], completed: true, accent: "orange" },
    { id: "reset", name: "Desk reset", focus: "Mobility", duration: 12, exercises: ["Neck rolls", "Hip opener", "Box breathing"], completed: false, accent: "mint" },
  ],
  goals: [],
  activity: [
    { day: "Mon", minutes: 24, habits: 3 }, { day: "Tue", minutes: 32, habits: 4 }, { day: "Wed", minutes: 18, habits: 3 },
    { day: "Thu", minutes: 38, habits: 4 }, { day: "Fri", minutes: 28, habits: 3 }, { day: "Sat", minutes: 44, habits: 4 }, { day: "Sun", minutes: 20, habits: 2 },
  ],
  settings: { notifications: false, weekStarts: "Monday", reducedMotion: false },
  lastActive: todayKey,
  dietLog: [],
};

function loadLocalData(): AppData {
  try {
    const saved = localStorage.getItem(STORAGE_KEY);
    if (saved) {
      const parsed = JSON.parse(saved) as Partial<AppData>;
      return { ...starterData, ...parsed, goals: Array.isArray(parsed.goals) ? parsed.goals : [] };
    }
  } catch {
    // Local cache can be unavailable in private browsing. Keep the app usable.
  }
  return starterData;
}

function formatDate() {
  return new Intl.DateTimeFormat("en-US", { weekday: "long", month: "long", day: "numeric" }).format(new Date());
}

function DogMark({ mood = "happy", size = "small" }: { mood?: "happy" | "sad" | "supportive"; size?: "small" | "large" }) {
  return (
    <div className={`dog-mark dog-${mood} dog-${size}`} aria-label={`Streakly dog is ${mood}`}>
      <span className="dog-ear dog-ear-left" />
      <span className="dog-ear dog-ear-right" />
      <span className="dog-face"><span className="dog-eye dog-eye-left" /><span className="dog-eye dog-eye-right" /><span className="dog-muzzle">{mood === "sad" ? "⌣" : mood === "supportive" ? "•ᴗ•" : "◡"}</span></span>
      <span className="dog-cheek">✦</span>
    </div>
  );
}

function StatCard({ icon, value, label, tone }: { icon: React.ReactNode; value: string; label: string; tone: string }) {
  return <div className={`stat-card tone-${tone}`}><span className="stat-icon">{icon}</span><div><strong>{value}</strong><span>{label}</span></div></div>;
}

function SectionTitle({ eyebrow, title, action, onAction }: { eyebrow?: string; title: string; action?: string; onAction?: () => void }) {
  return <div className="section-title"><div>{eyebrow && <span className="eyebrow">{eyebrow}</span>}<h2>{title}</h2></div>{action && <button className="text-button" onClick={onAction}>{action}<ChevronRight size={15} /></button>}</div>;
}

function EmptyState({ icon, title, description, action, onAction }: { icon: React.ReactNode; title: string; description: string; action: string; onAction: () => void }) {
  return <div className="empty-state"><div className="empty-icon">{icon}</div><h3>{title}</h3><p>{description}</p><button className="primary-button" onClick={onAction}><Plus size={17} />{action}</button></div>;
}

export default function Home() {
  const { user, loading: authLoading, isAuthenticated, logout } = useAuth();
  const [tab, setTab] = useState<Tab>("overview");
  const [data, setData] = useState<AppData>(() => loadLocalData());
  const [hydrated, setHydrated] = useState(false);
  const [online, setOnline] = useState(() => typeof navigator === "undefined" ? true : navigator.onLine);
  const [notice, setNotice] = useState<{ type: "success" | "error" | "info"; text: string } | null>(null);
  const [query, setQuery] = useState("");
  const [habitFilter, setHabitFilter] = useState("All");
  const [showHabitForm, setShowHabitForm] = useState(false);
  const [showWorkoutForm, setShowWorkoutForm] = useState(false);
  const [showOnboarding, setShowOnboarding] = useState(() => {
    try { return localStorage.getItem("streakly-onboarded-v1") !== "1"; } catch { return true; }
  });
  const [newHabit, setNewHabit] = useState({ name: "", emoji: "✨", category: "Mind", goal: "10 minutes" });
  const [newWorkout, setNewWorkout] = useState({ name: "", focus: "Strength", duration: 20 });
  const [activeWorkout, setActiveWorkout] = useState<string | null>(null);
  const [secondsLeft, setSecondsLeft] = useState(0);
  const [installPrompt, setInstallPrompt] = useState<BeforeInstallPromptEvent | null>(null);
  const [chatOpen, setChatOpen] = useState(false);
  const [chatMode, setChatMode] = useState<"chat" | "plan">("chat");
  const [chatMessages, setChatMessages] = useState<Message[]>([]);
  const saveMutation = trpc.appData.save.useMutation();
  const chatMutation = trpc.ai.chat.useMutation();
  const serverData = trpc.appData.get.useQuery(undefined, { enabled: isAuthenticated, retry: false });
  const hasLoadedServer = useRef(false);

  useEffect(() => {
    const onOnline = () => { setOnline(true); setNotice({ type: "success", text: "Back online — your next change will sync." }); };
    const onOffline = () => { setOnline(false); setNotice({ type: "info", text: "Offline mode on — changes are safe on this device." }); };
    const onInstall = (event: Event) => { event.preventDefault(); setInstallPrompt(event as BeforeInstallPromptEvent); };
    window.addEventListener("online", onOnline);
    window.addEventListener("offline", onOffline);
    window.addEventListener("beforeinstallprompt", onInstall);
    return () => { window.removeEventListener("online", onOnline); window.removeEventListener("offline", onOffline); window.removeEventListener("beforeinstallprompt", onInstall); };
  }, []);

  useEffect(() => {
    if (!isAuthenticated || !serverData.isSuccess || hasLoadedServer.current) return;
    hasLoadedServer.current = true;
    if (serverData.data) {
      try {
        const remote = JSON.parse(serverData.data) as AppData;
        setData({ ...starterData, ...remote, goals: Array.isArray(remote.goals) ? remote.goals : [] });
        localStorage.setItem(STORAGE_KEY, serverData.data);
        setNotice({ type: "success", text: "Synced with your account." });
      } catch {
        setNotice({ type: "error", text: "We found a sync issue. Your local plan is still safe." });
      }
    } else {
      saveMutation.mutate({ payload: JSON.stringify(data) });
    }
    setHydrated(true);
  }, [isAuthenticated, serverData.isSuccess, serverData.data]);

  useEffect(() => {
    if (!isAuthenticated && !authLoading) setHydrated(true);
  }, [isAuthenticated, authLoading]);

  useEffect(() => {
    if (!activeWorkout || secondsLeft <= 0) return;
    const timer = window.setInterval(() => setSecondsLeft(value => value - 1), 1000);
    return () => window.clearInterval(timer);
  }, [activeWorkout, secondsLeft]);

  useEffect(() => {
    if (secondsLeft === 0 && activeWorkout) {
      setNotice({ type: "success", text: "Session complete — you showed up for yourself." });
      setData(prev => ({ ...prev, workouts: prev.workouts.map(item => item.id === activeWorkout ? { ...item, completed: true } : item) }));
      setActiveWorkout(null);
    }
  }, [secondsLeft, activeWorkout]);

  useEffect(() => {
    if (!notice) return;
    const timeout = window.setTimeout(() => setNotice(null), 4200);
    return () => window.clearTimeout(timeout);
  }, [notice]);

  const updateData = (updater: (current: AppData) => AppData, message?: string) => {
    setData(current => {
      const next = updater(current);
      try { localStorage.setItem(STORAGE_KEY, JSON.stringify(next)); } catch { /* stay usable without storage */ }
      if (isAuthenticated && online) saveMutation.mutate({ payload: JSON.stringify(next) });
      return next;
    });
    if (message) setNotice({ type: "success", text: message });
  };

  const completeHabit = (habitId: string) => {
    updateData(current => ({ ...current, lastActive: todayKey, habits: current.habits.map(habit => habit.id === habitId ? { ...habit, completedToday: !habit.completedToday, streak: habit.completedToday ? Math.max(0, habit.streak - 1) : habit.streak + 1, bestStreak: habit.completedToday ? habit.bestStreak : Math.max(habit.bestStreak, habit.streak + 1) } : habit) }), "Nice work — your dog is doing a happy dance.");
  };

  const addHabit = () => {
    if (!newHabit.name.trim()) return;
    updateData(current => ({ ...current, habits: [...current.habits, { id: `habit-${Date.now()}`, name: newHabit.name.trim(), emoji: newHabit.emoji, category: newHabit.category, frequency: "Daily", goal: newHabit.goal, streak: 0, bestStreak: 0, completedToday: false, reminder: "Not set", accent: "purple" }] }), "Habit added to your daily rhythm.");
    setNewHabit({ name: "", emoji: "✨", category: "Mind", goal: "10 minutes" });
    setShowHabitForm(false);
  };

  const addWorkout = () => {
    if (!newWorkout.name.trim()) return;
    updateData(current => ({ ...current, workouts: [...current.workouts, { id: `workout-${Date.now()}`, name: newWorkout.name.trim(), focus: newWorkout.focus, duration: newWorkout.duration, exercises: ["Warm-up", "Main set", "Cool-down"], completed: false, accent: "purple" }] }), "Workout plan ready when you are.");
    setNewWorkout({ name: "", focus: "Strength", duration: 20 });
    setShowWorkoutForm(false);
  };

  const logFood = (foodId: string, servings: number) => {
    updateData(current => {
      const currentLog = current.dietLog ?? [];
      const existing = currentLog.find(entry => entry.foodId === foodId);
      return { ...current, dietLog: existing ? currentLog.map(entry => entry.foodId === foodId ? { ...entry, servings: entry.servings + servings } : entry) : [...currentLog, { id: `food-${Date.now()}`, foodId, servings }] };
    }, "Added to your food log.");
  };

  const removeFood = (foodId: string) => updateData(current => ({ ...current, dietLog: (current.dietLog ?? []).filter(entry => entry.foodId !== foodId) }), "Removed from today’s food log.");

  const startWorkout = (workout: Workout) => {
    setActiveWorkout(workout.id);
    setSecondsLeft(workout.duration * 60);
    setTab("workouts");
    setNotice({ type: "info", text: `${workout.name} started. One breath, then the next rep.` });
  };

  const filteredHabits = useMemo(() => data.habits.filter(habit => (habitFilter === "All" || habit.category === habitFilter) && habit.name.toLowerCase().includes(query.toLowerCase())), [data.habits, habitFilter, query]);
  const completedHabits = data.habits.filter(habit => habit.completedToday).length;
  const activeStreak = Math.max(...data.habits.map(habit => habit.streak), 0);
  const weeklyPercent = Math.round((data.activity.reduce((sum, day) => sum + day.habits, 0) / (data.activity.length * 4)) * 100);
  const dogMood: "happy" | "sad" | "supportive" = completedHabits >= 2 ? "happy" : activeStreak > 0 ? "supportive" : "sad";
  const dogCopy = dogMood === "happy" ? "You’re on a roll. I can feel the momentum." : dogMood === "supportive" ? "Tiny steps still count. Let’s make today kind." : "I miss you. No guilt — we can restart with one tiny win.";
  const pieData = [
    { name: "Body", value: data.habits.filter(h => h.category === "Body").length },
    { name: "Mind", value: data.habits.filter(h => h.category === "Mind").length },
    { name: "Life", value: data.habits.filter(h => h.category === "Life").length },
  ].filter(item => item.value > 0);

  const navigate = (nextTab: Tab) => { setTab(nextTab); window.scrollTo({ top: 0, behavior: "smooth" }); };
  const enableNotifications = async () => {
    if (!("Notification" in window)) { setNotice({ type: "error", text: "Notifications are not supported in this browser." }); return; }
    const permission = await Notification.requestPermission();
    if (permission === "granted") { updateData(current => ({ ...current, settings: { ...current.settings, notifications: true } }), "Reminders are on — we’ll nudge you gently."); }
    else setNotice({ type: "info", text: "Permission is off. You can enable reminders in your browser settings." });
  };
  const installApp = async () => {
    if (installPrompt) { await installPrompt.prompt(); setInstallPrompt(null); return; }
    setNotice({ type: "info", text: "Use your browser menu and choose ‘Install Streakly’ or ‘Add to Home screen’." });
  };
  const timeLabel = `${String(Math.floor(secondsLeft / 60)).padStart(2, "0")}:${String(secondsLeft % 60).padStart(2, "0")}`;
  const sendChatMessage = async (content: string) => {
    const nextMessages: Message[] = [...chatMessages, { role: "user" as const, content }].slice(-16);
    const apiMessages = nextMessages.map(message => ({ role: message.role as "user" | "assistant", content: message.content }));
    setChatMessages(nextMessages);
    const context = [
      `Today's habits: ${data.habits.map(habit => `${habit.name} (${habit.goal}; ${habit.completedToday ? "done today" : "not done today"}; ${habit.streak}-day streak)`).join("; ") || "none yet"}.`,
      `Workouts: ${data.workouts.map(workout => `${workout.name} (${workout.duration} minutes${workout.completed ? ", completed" : ""})`).join("; ") || "none yet"}.`,
    ].join(" ").slice(0, 6_000);
    try {
      const answer = await chatMutation.mutateAsync({ messages: apiMessages, context });
      const reply: Message = { role: "assistant", content: answer };
      setChatMessages(current => [...current, reply].slice(-17));
    } catch (error) {
      const message = error instanceof Error ? error.message : "The assistant is temporarily unavailable. Please try again.";
      const reply: Message = { role: "assistant", content: message };
      setChatMessages(current => [...current, reply].slice(-17));
    }
  };

  const openAIChat = () => { setChatMode("chat"); setChatOpen(true); };
  const openGoalPlanner = () => { setChatMode("plan"); setChatOpen(true); };
  const applyGoalPlan = (plan: GoalPlanDraft) => {
    const newHabits: Habit[] = plan.habits.map(habit => ({
      id: `habit-${crypto.randomUUID()}`,
      name: habit.name,
      emoji: habit.emoji,
      category: habit.category,
      frequency: habit.frequency,
      goal: habit.goal,
      streak: 0,
      bestStreak: 0,
      completedToday: false,
      reminder: "Not set",
      accent: habit.category === "Body" ? "mint" : habit.category === "Life" ? "orange" : "purple",
    }));
    const savedGoal: SavedGoal = {
      ...plan,
      id: `goal-${crypto.randomUUID()}`,
      createdAt: new Date().toISOString(),
      habitIds: newHabits.map(habit => habit.id),
      completedMilestones: [],
    };
    const successMessage = newHabits.length === 0
      ? `“${plan.title}” saved without adding new habits.`
      : `“${plan.title}” added with ${newHabits.length} new habit${newHabits.length === 1 ? "" : "s"}.`;
    updateData(current => ({
      ...current,
      goals: [savedGoal, ...(current.goals ?? [])],
      habits: [...current.habits, ...newHabits],
    }), successMessage);
    setTab("progress");
    setChatMode("chat");
    setChatOpen(false);
  };
  const toggleGoalMilestone = (goalId: string, milestoneIndex: number) => updateData(current => ({
    ...current,
    goals: (current.goals ?? []).map(goal => {
      if (goal.id !== goalId) return goal;
      const completed = goal.completedMilestones ?? [];
      return {
        ...goal,
        completedMilestones: completed.includes(milestoneIndex)
          ? completed.filter(index => index !== milestoneIndex)
          : [...completed, milestoneIndex].sort((left, right) => left - right),
      };
    }),
  }));
  const removeGoal = (goalId: string) => {
    const goal = (data.goals ?? []).find(item => item.id === goalId);
    if (!goal || !window.confirm(`Remove “${goal.title}”? Habits already added will remain in your Habits list.`)) return;
    updateData(current => ({ ...current, goals: (current.goals ?? []).filter(item => item.id !== goalId) }), "Goal removed. Its habits remain in your Habits list.");
  };

  if (authLoading || (!hydrated && isAuthenticated && serverData.isLoading)) {
    return <div className="app-loading"><div className="loading-orb"><DogMark mood="supportive" size="large" /></div><span>Getting your rhythm ready…</span><div className="loading-lines"><i /><i /><i /></div></div>;
  }

  return (
    <div className={`app-shell ${tab === "overview" ? "figma-mode" : ""}`}>
      <aside className="side-rail">
        <div className="brand-lockup"><DogMark /><div><strong>streakly</strong><span>daily momentum</span></div></div>
        <nav className="primary-nav" aria-label="Primary navigation">
          <NavItem icon={<HomeIcon size={18} />} label="Today" active={tab === "overview"} onClick={() => navigate("overview")} />
          <NavItem icon={<Target size={18} />} label="Habits" active={tab === "habits"} onClick={() => navigate("habits")} badge={data.habits.length.toString()} />
          <NavItem icon={<Dumbbell size={18} />} label="Workouts" active={tab === "workouts"} onClick={() => navigate("workouts")} />
          <NavItem icon={<Utensils size={18} />} label="Diet" active={tab === "diet"} onClick={() => navigate("diet")} />
          <NavItem icon={<Trophy size={18} />} label="Progress" active={tab === "progress"} onClick={() => navigate("progress")} />
        </nav>
        <div className="rail-bottom"><div className="rail-tip"><Sparkles size={16} /><p><strong>Keep it kind.</strong><br />Consistency beats intensity.</p></div><NavItem icon={<Settings size={18} />} label="Settings" active={tab === "settings"} onClick={() => navigate("settings")} /></div>
      </aside>

      <main className="main-content">
        <header className="topbar"><button className="mobile-menu" aria-label="Open menu"><Menu size={21} /></button><div className="mobile-brand"><DogMark /><strong>streakly</strong></div><div className="topbar-spacer" /><div className={`sync-pill ${online ? "is-online" : "is-offline"}`}><span className="sync-dot" />{online ? "Synced" : "Offline mode"}</div><button className="icon-button notification-button" aria-label="Notifications" onClick={() => navigate("settings")}><BellRing size={19} /><span className="notification-dot" /></button><div className="user-avatar" aria-label={user?.name ?? "Guest profile"}>{user?.name?.slice(0, 1).toUpperCase() ?? "G"}</div></header>
        {!online && <div className="offline-banner"><WifiOff size={15} /><span>You’re offline. Your updates stay on this device and will sync when you reconnect.</span><button onClick={() => setNotice({ type: "info", text: "Still offline — we’ll keep your place." })}>Got it</button></div>}

        <div className="page-wrap">
          {tab === "overview" && <FigmaDashboard data={data} userName={user?.name} onComplete={completeHabit} onNavigate={navigate} onNewHabit={() => { setTab("habits"); setShowHabitForm(true); }} onIncrement={habitId => updateData(current => ({ ...current, habits: current.habits.map(habit => habit.id === habitId ? { ...habit, completedToday: true, streak: habit.streak + 1, bestStreak: Math.max(habit.bestStreak, habit.streak + 1) } : habit) }), "Nice — one more glass in.")} />}
          {tab === "habits" && <section className="page-section"><PageIntro eyebrow="YOUR RHYTHM" title="Habits that fit your life." description="Build the kind of consistency that leaves room for real life." action={<button className="primary-button" onClick={() => setShowHabitForm(true)}><Plus size={17} />New habit</button>} />{showHabitForm && <HabitForm value={newHabit} onChange={setNewHabit} onCancel={() => setShowHabitForm(false)} onSave={addHabit} />}<div className="toolbar"><div className="search-field"><Search size={17} /><input value={query} onChange={event => setQuery(event.target.value)} placeholder="Search habits" aria-label="Search habits" /></div><div className="filter-pills">{["All", "Body", "Mind", "Life"].map(filter => <button key={filter} className={habitFilter === filter ? "active" : ""} onClick={() => setHabitFilter(filter)}>{filter}</button>)}</div></div>{filteredHabits.length ? <div className="habit-grid">{filteredHabits.map(habit => <HabitCard key={habit.id} habit={habit} onComplete={() => completeHabit(habit.id)} />)}</div> : <EmptyState icon={<Target size={22} />} title="No habits found" description="Try another search or make a new habit that feels like you." action="Create a habit" onAction={() => setShowHabitForm(true)} />}</section>}
          {tab === "workouts" && <WorkoutsView workouts={data.workouts} activeWorkout={activeWorkout} secondsLeft={secondsLeft} showForm={showWorkoutForm} form={newWorkout} onFormChange={setNewWorkout} onShowForm={() => setShowWorkoutForm(true)} onCancelForm={() => setShowWorkoutForm(false)} onSave={addWorkout} onStart={startWorkout} onPause={() => setActiveWorkout(null)} onReset={() => setSecondsLeft((data.workouts.find(workout => workout.id === activeWorkout)?.duration ?? 0) * 60)} timeLabel={timeLabel} />}
          {tab === "diet" && <DietView entries={data.dietLog ?? []} onLog={logFood} onRemove={removeFood} />}
          {tab === "progress" && <><GoalPlansSection goals={data.goals ?? []} habits={data.habits} onCreatePlan={openGoalPlanner} onToggleMilestone={toggleGoalMilestone} onRemoveGoal={removeGoal} /><ProgressView data={data} pieData={pieData} weeklyPercent={weeklyPercent} activeStreak={activeStreak} onCreateGoalPlan={openGoalPlanner} /></>}
          {tab === "settings" && <SettingsView user={user} isAuthenticated={isAuthenticated} online={online} settings={data.settings} onNotifications={enableNotifications} onInstall={installApp} onLogout={logout} onToggleReducedMotion={() => updateData(current => ({ ...current, settings: { ...current.settings, reducedMotion: !current.settings.reducedMotion } }), "Motion preference saved.")} />}
        </div>
      </main>

      <nav className="bottom-nav" aria-label="Mobile navigation"><NavItem icon={<HomeIcon size={19} />} label="Today" active={tab === "overview"} onClick={() => navigate("overview")} /><NavItem icon={<Target size={19} />} label="Habits" active={tab === "habits"} onClick={() => navigate("habits")} /><NavItem icon={<Dumbbell size={19} />} label="Train" active={tab === "workouts"} onClick={() => navigate("workouts")} /><NavItem icon={<Utensils size={19} />} label="Diet" active={tab === "diet"} onClick={() => navigate("diet")} /><NavItem icon={<Trophy size={19} />} label="Progress" active={tab === "progress"} onClick={() => navigate("progress")} /><NavItem icon={<Settings size={19} />} label="More" active={tab === "settings"} onClick={() => navigate("settings")} /></nav>
      <Dialog open={chatOpen} onOpenChange={setChatOpen}>
        <DialogContent className="flex h-[min(760px,calc(100dvh-2rem))] w-[calc(100%-1rem)] flex-col gap-0 overflow-hidden bg-white p-0 sm:max-w-lg">
          <div className="flex items-start justify-between gap-3 border-b px-5 py-4 pr-12">
            <div>
              <DialogTitle className="flex items-center gap-2 text-left"><Sparkles size={18} className="text-primary" /> {chatMode === "chat" ? "Streakly AI coach" : "Plan toward your goal"}</DialogTitle>
              <DialogDescription className="mt-1 text-left">{chatMode === "chat" ? "Ask about habits, workouts, or using Streakly. Your message and a brief habit/workout summary go to Google Gemini; chat history isn’t saved." : "Describe the outcome you want. Your goal and a brief habit summary go to Google Gemini; nothing is saved until you apply the plan."}</DialogDescription>
            </div>
            {chatMode === "chat" && <button
              type="button"
              className="flex shrink-0 items-center gap-1 rounded-md px-2 py-1.5 text-xs font-medium text-muted-foreground transition hover:bg-muted hover:text-foreground disabled:cursor-not-allowed disabled:opacity-50"
              onClick={() => setChatMessages([])}
              disabled={chatMutation.isPending}
              aria-label="Start a new conversation"
              title="Start a new conversation"
            >
              <RotateCcw size={14} /> New chat
            </button>}
          </div>
          <div className="flex gap-2 border-b bg-white px-5 py-2" role="tablist" aria-label="AI coach modes">
            <button type="button" role="tab" aria-selected={chatMode === "chat"} onClick={() => setChatMode("chat")} className={`rounded-full px-3 py-1.5 text-xs font-semibold transition ${chatMode === "chat" ? "bg-[#e7eedf] text-[#315d43]" : "text-[#667368] hover:bg-[#f7f8f4]"}`}>Ask AI</button>
            <button type="button" role="tab" aria-selected={chatMode === "plan"} onClick={() => setChatMode("plan")} className={`rounded-full px-3 py-1.5 text-xs font-semibold transition ${chatMode === "plan" ? "bg-[#e7eedf] text-[#315d43]" : "text-[#667368] hover:bg-[#f7f8f4]"}`}>Build a goal plan</button>
          </div>
          <div className={`min-h-0 flex-1 p-3 sm:p-4 ${chatMode === "chat" ? "" : "hidden"}`}>
            <AIChatBox
                messages={chatMessages}
                onSendMessage={sendChatMessage}
                isLoading={chatMutation.isPending}
                height="100%"
                className="h-full"
                placeholder="Ask anything…"
                emptyStateMessage="What would you like help figuring out?"
                suggestedPrompts={[
                  "How can I make a habit easier to stick to?",
                  "What should I do after missing a day?",
                  "Help me plan a simple daily routine",
                ]}
              />
          </div>
          <div className={`min-h-0 flex-1 p-3 sm:p-4 ${chatMode === "plan" ? "" : "hidden"}`}>
            <AIGoalPlanner context={data.habits.map(habit => `${habit.name} (${habit.category}, ${habit.frequency}, goal: ${habit.goal})`).join("; ").slice(0, 3_000)} onApply={applyGoalPlan} />
          </div>
        </DialogContent>
      </Dialog>
      <button
        type="button"
        className="fixed bottom-24 right-5 z-40 flex items-center gap-2 rounded-full bg-[#6e6af6] px-4 py-3 text-sm font-semibold text-white shadow-lg transition hover:-translate-y-0.5 hover:bg-[#5d58e8] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#6e6af6] focus-visible:ring-offset-2 md:bottom-6"
        onClick={openAIChat}
        aria-label="Ask the AI coach a question"
      >
        <MessageCircle size={18} /> Ask AI
      </button>
      {notice && <div className={`toast toast-${notice.type}`} role="status"><span className="toast-icon">{notice.type === "success" ? <Check size={16} /> : notice.type === "error" ? <X size={16} /> : <Sparkles size={16} />}</span><span>{notice.text}</span><button onClick={() => setNotice(null)} aria-label="Dismiss"><X size={15} /></button></div>}
    </div>
  );
}

function NavItem({ icon, label, active, onClick, badge }: { icon: React.ReactNode; label: string; active: boolean; onClick: () => void; badge?: string }) {
  return <button className={`nav-item ${active ? "active" : ""}`} onClick={onClick} aria-current={active ? "page" : undefined}><span>{icon}</span><strong>{label}</strong>{badge && <em>{badge}</em>}</button>;
}

function PageIntro({ eyebrow, title, description, action }: { eyebrow: string; title: string; description: string; action: React.ReactNode }) {
  return <div className="page-intro"><div><span className="eyebrow">{eyebrow}</span><h1>{title}</h1><p>{description}</p></div>{action}</div>;
}

function Overview({ data, user, dogMood, dogCopy, activeStreak, weeklyPercent, completedHabits, showOnboarding, onDismissOnboarding, onNavigate, onComplete, onStartWorkout }: { data: AppData; user: { name?: string | null } | null; dogMood: "happy" | "sad" | "supportive"; dogCopy: string; activeStreak: number; weeklyPercent: number; completedHabits: number; showOnboarding: boolean; onDismissOnboarding: () => void; onNavigate: (tab: Tab) => void; onComplete: (id: string) => void; onStartWorkout: (workout: Workout) => void }) {
  return <section className="page-section overview-section"><div className="welcome-row"><div><span className="eyebrow">{formatDate().toUpperCase()}</span><h1>Good morning{user?.name ? `, ${user.name.split(" ")[0]}` : ""}.</h1><p>Make space for the things that make you feel like you.</p></div><button className="quick-add" onClick={() => onNavigate("habits")}><Plus size={18} /><span>Quick add</span></button></div>{showOnboarding && <OnboardingCard onDismiss={onDismissOnboarding} onNavigate={onNavigate} />}<div className="coach-card"><div className="coach-copy"><div className="coach-kicker"><span className="status-dot" />YOUR POCKET COACH</div><h2>{dogMood === "happy" ? "That’s the energy." : dogMood === "sad" ? "Let’s find one small win." : "You’re doing better than you think."}</h2><p>{dogCopy}</p><button className="soft-button" onClick={() => onNavigate("progress")}>See your progress <ChevronRight size={15} /></button></div><div className="coach-dog"><DogMark mood={dogMood} size="large" /><span className="sparkle sparkle-one">✦</span><span className="sparkle sparkle-two">✧</span></div></div><div className="stat-grid"><StatCard icon={<Flame size={19} />} value={`${activeStreak} days`} label="best active streak" tone="orange" /><StatCard icon={<HeartPulse size={19} />} value={`${weeklyPercent}%`} label="week on track" tone="purple" /><StatCard icon={<Dumbbell size={19} />} value={`${data.workouts.filter(w => w.completed).length + 2}`} label="sessions this month" tone="mint" /></div><div className="dashboard-grid"><div className="dashboard-main"><SectionTitle eyebrow="RIGHT NOW" title="Today’s rhythm" action="View all" onAction={() => onNavigate("habits")} /><div className="today-card"><div className="today-progress"><div className="progress-ring"><strong>{completedHabits}</strong><span>of {data.habits.length}</span></div><div><h3>Little wins add up.</h3><p>{completedHabits === data.habits.length ? "Everything checked. Go enjoy your day." : `${data.habits.length - completedHabits} gentle nudge${data.habits.length - completedHabits === 1 ? "" : "s"} left today.`}</p></div></div><div className="habit-list">{data.habits.slice(0, 3).map(habit => <HabitRow key={habit.id} habit={habit} onComplete={() => onComplete(habit.id)} />)}</div><button className="list-footer" onClick={() => onNavigate("habits")}>Manage habits <ChevronRight size={15} /></button></div><SectionTitle eyebrow="MOVE YOUR BODY" title="Suggested for today" action="All workouts" onAction={() => onNavigate("workouts")} /><div className="workout-suggestion">{data.workouts.slice(0, 2).map(workout => <WorkoutMini key={workout.id} workout={workout} onStart={() => onStartWorkout(workout)} />)}</div></div><aside className="dashboard-side"><SectionTitle eyebrow="THIS WEEK" title="A steady climb" /><div className="mini-chart-card"><div className="chart-head"><div><strong>+18%</strong><span>vs. last week</span></div><span className="chart-up">↗</span></div><div className="bar-chart"><ResponsiveContainer width="100%" height={120}><BarChart data={data.activity} margin={{ top: 12, right: 0, left: -28, bottom: 0 }}><XAxis dataKey="day" axisLine={false} tickLine={false} tick={{ fill: "#9996a9", fontSize: 10 }} /><YAxis hide /><Tooltip cursor={{ fill: "#f3f1fb" }} contentStyle={{ border: "0", borderRadius: "12px", boxShadow: "0 8px 20px rgba(29,33,64,.12)", fontSize: 12 }} /><Bar dataKey="habits" radius={[5, 5, 2, 2]} fill="#6e6af6" /></BarChart></ResponsiveContainer></div></div><div className="consistency-card"><div className="consistency-icon"><Zap size={18} /></div><div><strong>Consistency is a skill</strong><p>Show up for 2 more days to beat your best this month.</p></div><ChevronRight size={17} /></div><div className="sync-card"><Wifi size={16} /><div><strong>Across all your devices</strong><p>{user ? "Your account is syncing in the background." : "Sign in to keep your plan with you."}</p></div>{!user && <button onClick={startLogin}>Sign in</button>}</div></aside></div></section>;
}

function OnboardingCard({ onDismiss, onNavigate }: { onDismiss: () => void; onNavigate: (tab: Tab) => void }) {
  return <div className="onboarding-card"><div className="onboarding-dog"><DogMark mood="supportive" /></div><div className="onboarding-copy"><span className="eyebrow">3 QUICK STEPS</span><h3>Let’s set up your rhythm.</h3><p>Pick one habit, choose a short workout, and let your streak grow from there.</p><div className="onboarding-steps"><span><b>1</b> Pick a habit</span><span><b>2</b> Start small</span><span><b>3</b> Celebrate wins</span></div></div><button className="icon-button" onClick={onDismiss} aria-label="Dismiss onboarding"><X size={17} /></button><button className="onboarding-cta" onClick={() => { onDismiss(); onNavigate("habits"); }}>Set my first habit <ChevronRight size={15} /></button></div>;
}

function HabitRow({ habit, onComplete }: { habit: Habit; onComplete: () => void }) {
  return <div className="habit-row"><button className={`check-button ${habit.completedToday ? "checked" : ""}`} onClick={onComplete} aria-label={`${habit.completedToday ? "Uncheck" : "Complete"} ${habit.name}`}>{habit.completedToday && <Check size={15} />}</button><span className="habit-emoji">{habit.emoji}</span><div className="habit-row-info"><strong>{habit.name}</strong><span>{habit.frequency} · {habit.goal}</span></div><span className="row-streak"><Flame size={13} />{habit.streak}</span><MoreHorizontal size={18} className="muted-icon" /></div>;
}

function HabitCard({ habit, onComplete }: { habit: Habit; onComplete: () => void }) {
  return <article className={`habit-card accent-${habit.accent}`}><div className="habit-card-head"><span className="large-emoji">{habit.emoji}</span><button className={`check-button ${habit.completedToday ? "checked" : ""}`} onClick={onComplete} aria-label={`${habit.completedToday ? "Uncheck" : "Complete"} ${habit.name}`}>{habit.completedToday && <Check size={15} />}</button></div><h3>{habit.name}</h3><span className="habit-category">{habit.category} · {habit.frequency}</span><div className="habit-card-bottom"><div><strong>{habit.streak}</strong><span>day streak</span></div><div className="goal-text"><span>Goal</span><strong>{habit.goal}</strong></div></div><div className="habit-card-footer"><span><Bell size={13} /> {habit.reminder}</span><span className="best-streak">Best {habit.bestStreak}</span></div></article>;
}

function HabitForm({ value, onChange, onCancel, onSave }: { value: { name: string; emoji: string; category: string; goal: string }; onChange: (value: { name: string; emoji: string; category: string; goal: string }) => void; onCancel: () => void; onSave: () => void }) {
  return <div className="form-card"><div className="form-card-header"><div><span className="eyebrow">NEW ROUTINE</span><h3>Make it feel like you.</h3></div><button className="icon-button" onClick={onCancel} aria-label="Close"><X size={18} /></button></div><div className="form-grid"><label>Habit name<input autoFocus value={value.name} onChange={event => onChange({ ...value, name: event.target.value })} placeholder="e.g. 10 minute walk" /></label><label>Emoji<input value={value.emoji} onChange={event => onChange({ ...value, emoji: event.target.value })} maxLength={2} /></label><label>Category<select value={value.category} onChange={event => onChange({ ...value, category: event.target.value })}><option>Mind</option><option>Body</option><option>Life</option></select></label><label>Daily goal<input value={value.goal} onChange={event => onChange({ ...value, goal: event.target.value })} placeholder="e.g. 10 minutes" /></label></div><div className="form-actions"><button className="quiet-button" onClick={onCancel}>Cancel</button><button className="primary-button" onClick={onSave}><Check size={17} />Save habit</button></div></div>;
}

function WorkoutMini({ workout, onStart }: { workout: Workout; onStart: () => void }) {
  return <div className={`workout-mini accent-${workout.accent}`}><div className="workout-mini-top"><span className="workout-icon"><Dumbbell size={18} /></span><span>{workout.focus}</span></div><h3>{workout.name}</h3><p><Clock3 size={13} />{workout.duration} min · {workout.exercises.length} moves</p><button className="start-button" onClick={onStart}><Play size={14} fill="currentColor" />Start</button></div>;
}

function WorkoutsView({ workouts, activeWorkout, secondsLeft, showForm, form, onFormChange, onShowForm, onCancelForm, onSave, onStart, onPause, onReset, timeLabel }: { workouts: Workout[]; activeWorkout: string | null; secondsLeft: number; showForm: boolean; form: { name: string; focus: string; duration: number }; onFormChange: (value: { name: string; focus: string; duration: number }) => void; onShowForm: () => void; onCancelForm: () => void; onSave: () => void; onStart: (workout: Workout) => void; onPause: () => void; onReset: () => void; timeLabel: string }) {
  const active = workouts.find(workout => workout.id === activeWorkout);
  return <section className="page-section"><PageIntro eyebrow="TRAIN SMART" title="Your body, your pace." description="Short, focused sessions for the days you actually have." action={<button className="primary-button" onClick={onShowForm}><Plus size={17} />New workout</button>} />{active && <div className="timer-panel"><div className="timer-copy"><span className="eyebrow">IN SESSION · {active.focus.toUpperCase()}</span><h2>{active.name}</h2><p>Keep your breath smooth. You’re exactly where you need to be.</p><div className="timer-controls"><button className="timer-main-button" onClick={secondsLeft > 0 ? onPause : () => onStart(active)}>{secondsLeft > 0 ? <Pause size={17} fill="currentColor" /> : <Play size={17} fill="currentColor" />}{secondsLeft > 0 ? "Pause" : "Resume"}</button><button className="timer-reset-button" onClick={onReset}><RotateCcw size={16} />Reset</button></div></div><div className="timer-clock"><span>{timeLabel}</span><small>remaining</small></div></div>}{showForm && <div className="form-card"><div className="form-card-header"><div><span className="eyebrow">NEW SESSION</span><h3>Give it a name.</h3></div><button className="icon-button" onClick={onCancelForm} aria-label="Close"><X size={18} /></button></div><div className="form-grid"><label>Workout name<input autoFocus value={form.name} onChange={event => onFormChange({ ...form, name: event.target.value })} placeholder="e.g. Saturday sweat" /></label><label>Focus<select value={form.focus} onChange={event => onFormChange({ ...form, focus: event.target.value })}><option>Strength</option><option>Cardio</option><option>Mobility</option><option>Recovery</option></select></label><label>Duration (minutes)<input type="number" min={5} max={120} value={form.duration} onChange={event => onFormChange({ ...form, duration: Number(event.target.value) })} /></label></div><div className="form-actions"><button className="quiet-button" onClick={onCancelForm}>Cancel</button><button className="primary-button" onClick={onSave}><Check size={17} />Save workout</button></div></div>}<div className="workouts-heading"><SectionTitle eyebrow="YOUR PLAN" title="Workouts" /><span className="muted-label">{workouts.filter(workout => workout.completed).length} completed this month</span></div><div className="workout-grid">{workouts.map(workout => <article className={`workout-card accent-${workout.accent}`} key={workout.id}><div className="workout-card-top"><span className="workout-icon"><Dumbbell size={19} /></span><span className="focus-pill">{workout.focus}</span>{workout.completed && <span className="completed-label"><Check size={13} />Done</span>}</div><h3>{workout.name}</h3><p className="workout-meta"><Clock3 size={14} />{workout.duration} minutes · {workout.exercises.length} exercises</p><div className="exercise-list">{workout.exercises.map(exercise => <span key={exercise}>{exercise}</span>)}</div><button className="wide-start" onClick={() => onStart(workout)}>{workout.completed ? "Repeat session" : "Start session"}<ChevronRight size={16} /></button></article>)}</div></section>;
}

function ProgressView({ data, pieData, weeklyPercent, activeStreak, onCreateGoalPlan }: { data: AppData; pieData: { name: string; value: number }[]; weeklyPercent: number; activeStreak: number; onCreateGoalPlan: () => void }) {
  const lineData = data.activity.map(day => ({ ...day, score: Math.round((day.habits / 4) * 100) }));
  return <section className="page-section"><PageIntro eyebrow="LOOKING BACK" title="Progress you can feel." description="Notice the pattern, celebrate the effort, and keep moving forward." action={<button className="soft-button"><CalendarDays size={16} />Last 7 days</button>} /><div className="progress-kpis"><div><span>Habit score</span><strong>{weeklyPercent}%</strong><small>+12% from last week</small></div><div><span>Current streak</span><strong>{activeStreak} <em>days</em></strong><small>Best: 21 days</small></div><div><span>Time invested</span><strong>3h 20m</strong><small>Across 7 sessions</small></div></div><div className="charts-grid"><div className="chart-card chart-wide"><div className="chart-card-head"><div><span className="eyebrow">HABIT COMPLETION</span><h3>Keep the line moving.</h3></div><span className="chart-legend"><i className="legend-dot purple" />Completion score</span></div><ResponsiveContainer width="100%" height={220}><LineChart data={lineData} margin={{ top: 10, right: 8, left: -25, bottom: 0 }}><CartesianGrid strokeDasharray="4 5" vertical={false} stroke="#eceaf3" /><XAxis dataKey="day" axisLine={false} tickLine={false} tick={{ fill: "#9996a9", fontSize: 11 }} /><YAxis domain={[0, 100]} axisLine={false} tickLine={false} tick={{ fill: "#9996a9", fontSize: 10 }} /><Tooltip contentStyle={{ border: "0", borderRadius: "12px", boxShadow: "0 8px 20px rgba(29,33,64,.12)", fontSize: 12 }} /><Line type="monotone" dataKey="score" stroke="#6e6af6" strokeWidth={3} dot={{ r: 4, fill: "#6e6af6", stroke: "#fff", strokeWidth: 2 }} activeDot={{ r: 6 }} /></LineChart></ResponsiveContainer></div><div className="chart-card"><div className="chart-card-head"><div><span className="eyebrow">TIME INVESTED</span><h3>Move minutes</h3></div><span className="chart-up">+18%</span></div><ResponsiveContainer width="100%" height={190}><BarChart data={data.activity} margin={{ top: 10, right: 0, left: -30, bottom: 0 }}><CartesianGrid strokeDasharray="4 5" vertical={false} stroke="#eceaf3" /><XAxis dataKey="day" axisLine={false} tickLine={false} tick={{ fill: "#9996a9", fontSize: 10 }} /><YAxis axisLine={false} tickLine={false} tick={{ fill: "#9996a9", fontSize: 10 }} /><Tooltip contentStyle={{ border: "0", borderRadius: "12px", boxShadow: "0 8px 20px rgba(29,33,64,.12)", fontSize: 12 }} /><Bar dataKey="minutes" fill="#ff9f68" radius={[6, 6, 2, 2]} /></BarChart></ResponsiveContainer></div><div className="chart-card pie-card"><div className="chart-card-head"><div><span className="eyebrow">YOUR MIX</span><h3>Where energy goes</h3></div></div><div className="pie-wrap"><ResponsiveContainer width="52%" height={180}><PieChart><Pie data={pieData} dataKey="value" nameKey="name" innerRadius={48} outerRadius={70} paddingAngle={4} stroke="none">{pieData.map((entry, index) => <Cell key={entry.name} fill={chartColors[index % chartColors.length]} />)}</Pie><Tooltip contentStyle={{ border: "0", borderRadius: "12px", fontSize: 12 }} /></PieChart></ResponsiveContainer><div className="pie-legend">{pieData.map((item, index) => <div key={item.name}><i style={{ background: chartColors[index % chartColors.length] }} /><span>{item.name}</span><strong>{item.value}</strong></div>)}</div></div></div></div><div className="insight-banner"><div className="insight-icon"><Sparkles size={20} /></div><div><span className="eyebrow">A LITTLE INSIGHT</span><h3>Your best days start with a small promise.</h3><p>You complete 24% more habits when you start before 9 AM. Try putting your easiest win first tomorrow.</p></div><button className="soft-button" onClick={onCreateGoalPlan}>Make a plan <ChevronRight size={15} /></button></div></section>;
}

function SettingsView({ user, isAuthenticated, online, settings, onNotifications, onInstall, onLogout, onToggleReducedMotion }: { user: { name?: string | null; email?: string | null } | null; isAuthenticated: boolean; online: boolean; settings: AppData["settings"]; onNotifications: () => void; onInstall: () => void; onLogout: () => Promise<void>; onToggleReducedMotion: () => void }) {
  return <section className="page-section settings-section"><PageIntro eyebrow="YOUR SPACE" title="Settings that stay simple." description="Make Streakly work the way your day works." action={<button className="soft-button" onClick={onInstall}><Sparkles size={16} />Install app</button>} /><div className="settings-grid"><div className="settings-main"><div className="settings-card account-card"><div className="account-avatar">{user?.name?.slice(0, 1).toUpperCase() ?? "G"}</div><div><span className="eyebrow">ACCOUNT</span><h3>{user?.name ?? "Guest mode"}</h3><p>{user?.email ?? "Your local plan is ready. Sign in to sync it across devices."}</p></div>{isAuthenticated ? <button className="quiet-button" onClick={onLogout}><LogOut size={15} />Log out</button> : <button className="primary-button" onClick={startLogin}><UserRound size={15} />Sign in to sync</button>}</div><div className="settings-card"><div className="settings-card-title"><div><span className="eyebrow">REMINDERS</span><h3>Gentle nudges</h3></div><BellRing size={18} /></div><div className="setting-row"><div><strong>Browser notifications</strong><span>{settings.notifications ? "Reminders are active." : "Not enabled yet."}</span></div><button className={`toggle ${settings.notifications ? "on" : ""}`} onClick={onNotifications} aria-pressed={settings.notifications}><i /></button></div><div className="permission-note"><CircleHelp size={14} /><span>You control the permission. We’ll never send more than your plan asks for.</span></div></div><div className="settings-card"><div className="settings-card-title"><div><span className="eyebrow">ACCESSIBILITY</span><h3>Make it comfortable</h3></div><HeartPulse size={18} /></div><div className="setting-row"><div><strong>Reduce motion</strong><span>Use calmer transitions and fewer effects.</span></div><button className={`toggle ${settings.reducedMotion ? "on" : ""}`} onClick={onToggleReducedMotion} aria-pressed={settings.reducedMotion}><i /></button></div></div></div><aside className="settings-side"><div className={`connection-card ${online ? "connected" : "disconnected"}`}><span>{online ? <Wifi size={18} /> : <WifiOff size={18} />}</span><div><strong>{online ? "You’re connected" : "Offline mode"}</strong><p>{online ? isAuthenticated ? "Your account is ready to sync." : "Sign in to keep your details everywhere." : "Changes are saved on this device."}</p></div></div><div className="install-card"><div className="install-icon"><DownloadIcon /></div><h3>Your plan, one tap away.</h3><p>Add Streakly to your home screen for a focused, app-like experience on mobile or desktop.</p><button className="primary-button" onClick={onInstall}>Install Streakly <ChevronRight size={15} /></button></div><div className="help-card"><Sparkles size={17} /><div><strong>Need a reset?</strong><p>Recovery is a feature, not a failure. Start with one habit today.</p></div></div></aside></div></section>;
}

function DownloadIcon() { return <span className="download-icon"><span>↓</span></span>; }

type BeforeInstallPromptEvent = Event & { prompt: () => Promise<void>; userChoice: Promise<{ outcome: "accepted" | "dismissed" }> };
