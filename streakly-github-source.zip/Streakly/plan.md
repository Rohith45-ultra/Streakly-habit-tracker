# Streakly — Habit & Wellness Tracker

## Implementation approach

Continue the supplied responsive React web app on the initialized React/Express/tRPC/Drizzle stack; preserve the existing product rather than replacing it with a new starter screen. Keep it browser-first and installable as a PWA so it works from phone and PC without app-store distribution. Preserve Manus OAuth account access and the authenticated user's managed MySQL app-data row for cross-device persistence; localStorage remains the offline/demo cache with a visible sync state.

The primary client surface is the existing dashboard shell with a left rail on desktop and bottom navigation on mobile. Dashboard, Habits, Workouts, Diet, Progress, and Settings remain focused in-app views. Preserve the compact creation/manage flows, progress charts, workout timer, browser-notification permission behavior, and responsive states already implemented.

Keep the AI coach in a floating dashboard chat panel. Give the dialog, transcript area, starter prompts, and composer solid white backgrounds rather than transparency. It answers questions about habits, routines, workouts, wellness, and using Streakly. The client sends a bounded transcript and relevant tracker context to a server-only tRPC mutation; the server calls Google's Gemini `generateContent` API and reads `GEMINI_API_KEY` only at runtime. Store that credential as a protected WebDev secret, never in source, Git, or browser output. The assistant should be concise, kind, and actionable, must not diagnose or treat medical conditions, and should direct medical or urgent concerns to a qualified professional. Conversations are not stored: the panel starts blank with suggested prompts, and **New chat** clears the visible transcript and restores those prompts.

Add a second coach mode, **Build a goal plan**, for turning a personal target outcome into a structured plan. The user may include a target date, starting point, weekly availability, or constraints in a prompt of up to 500 characters. A server-only Gemini procedure returns a Zod-validated goal title, summary, success measure, 2–52-week timeframe, 2–8 milestones, and 2–6 habits with category, frequency, and a concrete goal. The panel previews the draft and lets the user include or skip each proposed habit to avoid duplicates; nothing is stored until the user selects **Add plan to Streakly**. Applying creates a saved goal linked only to selected new habits through the existing app-data payload, preserving existing habits and account/local persistence. The Progress view shows plans and lets the user mark milestones; removing a goal leaves its added habits intact. Disclose that the goal and a concise current-habit summary are sent to Gemini. Both Gemini procedures enforce hourly per-IP and per-account limits plus a per-process request ceiling before contacting the provider; these counters are process-local and should move to shared storage if the service later runs multiple replicas. Keep health guidance general and non-diagnostic; avoid extreme exercise or diet prescriptions and include a qualified-care note when appropriate.

Server routes keep one protected app-data document per authenticated user. The document contains the user's habits, workout plans, diet log, completion history, and preferences; ownership remains tied to the authenticated user id. The UI keeps the local cache in sync and recovers gracefully when the network is unavailable. Preserve the real Manus OAuth flow and the Preview-compatible `webdev_app_session` cookie rather than inventing a development login.

## Project structure

- `client/src/pages/Home.tsx`: authenticated/guest-aware app shell, dashboard, habits, workouts, diet, progress, settings, timer, AI assistant panel, and interaction state.
- `client/src/components/AIChatBox.tsx`: chat transcript, starter prompts, message entry, and loading/error presentation.
- `client/src/components/GoalPlanning.tsx`: goal prompt, AI plan preview/apply flow, and saved goals with milestone progress.
- `client/src/index.css`: visual tokens, responsive layout, chart surfaces, dog companion styles, and state treatments.
- `client/public/manifest.webmanifest` and icons: installable browser manifest and PWA identity.
- `client/public/manus-routes.json`: route manifest for `/` and `/404`.
- `shared/goalPlan.ts`: shared Zod schema and TypeScript types for validated AI-generated goal plans and saved goals.
- `drizzle/schema.ts`, `drizzle/relations.ts`, and `drizzle/`: user and app-data schema plus additive migrations.
- `server/db.ts`: read/write helpers for the single user-owned payload.
- `server/routers.ts`: authentication, protected app-data, Gemini chat, and validated Gemini goal-plan procedures.
- `server/aiRateLimit.ts`: process-local hourly request buckets per IP/account/action and an overall per-process ceiling for Gemini calls.
- `server/aiRateLimit.test.ts`: deterministic coverage for IP, account, process, and window-reset behavior.
- `server/_core/`: Express/tRPC/OAuth runtime, public health route, and production static serving.
- `Dockerfile`: pinned pnpm install, frontend/server build, and production `dist/index.js` entrypoint.

## Design direction

The supplied Figma dashboard is the approved visual source of truth for the Today view. Preserve the existing quiet editorial wellness dashboard and product behavior.

- **Design Movement:** quiet editorial wellness dashboard with a premium habit-journal feel.
- **Core Principles:** calm one-glance clarity; warm encouragement over guilt; generous whitespace; compact actions that remain easy to reach.
- **Color Philosophy:** cream background `#f7f8f4`, forest green `#427356` for completion and primary actions, sage `#e7eedf` for progress, soft stone borders `#e7ebe3`, and muted green-gray supporting text.
- **Layout Paradigm:** a large two-column desktop workspace with a wide Today's habits card and a narrower weekly insight rail, collapsing into a single stacked mobile flow.
- **Signature Elements:** thin stone borders, rounded 20px cards, progress ring, vertical weekly bars, and the botanical “How are you feeling today?” card.
- **Interaction Philosophy:** every completion row is actionable, filters and navigation remain quiet, and new habit creation is available from the top action or the end of the list.
- **Animation:** keep motion restrained and respect reduced-motion preferences; favor immediate completion feedback over decorative movement.
- **Typography System:** `Lora` for display headings and `Inter` for UI/body copy, matching the supplied Figma frame.
- **Brand Essence:** a calm daily habit companion that makes showing up feel visible and achievable.
- **Brand Voice:** reassuring and specific (“A little better, every day.”; “A few small steps, and you’re already moving forward.”).
- **Wordmark & Logo:** retain the Streakly dog mark in the app shell, while the Today dashboard uses the Figma frame's quiet editorial hierarchy.
- **Signature Brand Color:** forest green `#427356`.

## Hosting and production workflow

Use the initialized managed WebDev server and MySQL database. The Dockerfile builds the committed app with the pinned pnpm toolchain and runs the production server on the platform-provided `PORT` (default 3000). Keep `GET /api/health` unauthenticated for the configured deployment readiness check. Runtime credentials, including `DATABASE_URL` and the Gemini key, are read at runtime and are not required during image compilation. Preserve durable tracker records in the managed database rather than container memory or files. After migration and validation, fetch/integrate canonical `origin/main`, push the tested intended commit to `main` to record a checkpoint, then use the explicit Publish operation to deploy that checkpoint; the initialized auto-publish setting is off.
