import { describe, expect, it } from "vitest";
import { AiRateLimiter } from "./aiRateLimit";

describe("AiRateLimiter", () => {
  it("limits goal-plan requests by IP", () => {
    const limiter = new AiRateLimiter(() => 1_000);
    for (let index = 0; index < 12; index += 1) {
      expect(limiter.consume("goalPlan", { ip: "203.0.113.4" })).toBe(0);
    }
    expect(limiter.consume("goalPlan", { ip: "203.0.113.4" })).toBeGreaterThan(0);
  });

  it("limits signed-in callers by account even when their IP changes", () => {
    const limiter = new AiRateLimiter(() => 1_000);
    for (let index = 0; index < 6; index += 1) {
      expect(limiter.consume("goalPlan", { ip: `203.0.113.${index}`, userId: "account-1" })).toBe(0);
    }
    expect(limiter.consume("goalPlan", { ip: "203.0.113.99", userId: "account-1" })).toBeGreaterThan(0);
    expect(limiter.consume("goalPlan", { ip: "203.0.113.99", userId: "account-2" })).toBe(0);
  });

  it("enforces a process-wide ceiling across distinct identities", () => {
    const limiter = new AiRateLimiter(() => 1_000);
    for (let index = 0; index < 100; index += 1) {
      expect(limiter.consume("goalPlan", { ip: `198.51.100.${index}` })).toBe(0);
    }
    expect(limiter.consume("goalPlan", { ip: "198.51.100.200" })).toBeGreaterThan(0);
  });

  it("keeps an active IP limit after sweeping unrelated identities", () => {
    const limiter = new AiRateLimiter(() => 1_000);
    for (let index = 0; index < 12; index += 1) {
      expect(limiter.consume("goalPlan", { ip: "203.0.113.77", userId: `account-${index}` })).toBe(0);
    }
    for (let index = 0; index < 100; index += 1) {
      expect(limiter.consume("chat", { ip: `198.51.100.${index}`, userId: `chat-account-${index}` })).toBe(0);
    }
    expect(limiter.consume("goalPlan", { ip: "203.0.113.77", userId: "new-account" })).toBeGreaterThan(0);
  });

  it("keeps an active account limit after sweeping unrelated identities", () => {
    const limiter = new AiRateLimiter(() => 1_000);
    for (let index = 0; index < 6; index += 1) {
      expect(limiter.consume("goalPlan", { ip: `203.0.113.${index}`, userId: "account-1" })).toBe(0);
    }
    for (let index = 0; index < 100; index += 1) {
      expect(limiter.consume("chat", { ip: `198.51.100.${index}`, userId: `chat-account-${index}` })).toBe(0);
    }
    expect(limiter.consume("goalPlan", { ip: "203.0.113.99", userId: "account-1" })).toBeGreaterThan(0);
  });

  it("allows requests again after the hourly window expires", () => {
    let now = 1_000;
    const limiter = new AiRateLimiter(() => now);
    for (let index = 0; index < 6; index += 1) {
      limiter.consume("goalPlan", { ip: "192.0.2.5", userId: "account-1" });
    }
    expect(limiter.consume("goalPlan", { ip: "192.0.2.5", userId: "account-1" })).toBeGreaterThan(0);
    now += 60 * 60 * 1_000 + 1;
    expect(limiter.consume("goalPlan", { ip: "192.0.2.5", userId: "account-1" })).toBe(0);
  });
});
