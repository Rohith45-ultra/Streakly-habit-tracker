export type AiRateLimitAction = "chat" | "goalPlan";

export type AiRateLimitIdentity = {
  ip: string;
  userId?: string;
};

type LimitRule = {
  perIp: number;
  perAccount: number;
  perProcess: number;
  windowMs: number;
};

type WindowCounter = {
  count: number;
  resetAt: number;
};

const ONE_HOUR = 60 * 60 * 1_000;

const rules: Record<AiRateLimitAction, LimitRule> = {
  chat: { perIp: 60, perAccount: 30, perProcess: 300, windowMs: ONE_HOUR },
  goalPlan: { perIp: 12, perAccount: 6, perProcess: 100, windowMs: ONE_HOUR },
};

/**
 * Process-local request limits. The process ceiling caps accidental/API-key spend bursts;
 * use shared storage if the app is later deployed across multiple server replicas.
 */
export class AiRateLimiter {
  private readonly identities = new Map<string, WindowCounter>();
  private readonly processCounters: Partial<Record<AiRateLimitAction, WindowCounter>> = {};
  private callsSinceSweep = 0;

  constructor(private readonly now: () => number = Date.now) {}

  /** Returns 0 when allowed, otherwise milliseconds until the blocking window resets. */
  consume(action: AiRateLimitAction, identity: AiRateLimitIdentity): number {
    const rule = rules[action];
    const now = this.now();
    const keys = [
      { key: `${action}:ip:${identity.ip}`, limit: rule.perIp },
      ...(identity.userId ? [{ key: `${action}:user:${identity.userId}`, limit: rule.perAccount }] : []),
    ];
    const processCounter = this.processCounters[action];

    const identityBlock = keys
      .map(({ key, limit }) => ({ counter: this.identities.get(key), limit }))
      .find(({ counter, limit }) => counter && counter.resetAt > now && counter.count >= limit);
    const processBlocked = processCounter && processCounter.resetAt > now && processCounter.count >= rule.perProcess;

    if (identityBlock?.counter) return Math.max(1_000, identityBlock.counter.resetAt - now);
    if (processBlocked && processCounter) return Math.max(1_000, processCounter.resetAt - now);

    for (const { key } of keys) {
      const current = this.identities.get(key);
      this.identities.set(key, current && current.resetAt > now
        ? { count: current.count + 1, resetAt: current.resetAt }
        : { count: 1, resetAt: now + rule.windowMs });
    }

    this.processCounters[action] = processCounter && processCounter.resetAt > now
      ? { count: processCounter.count + 1, resetAt: processCounter.resetAt }
      : { count: 1, resetAt: now + rule.windowMs };

    this.callsSinceSweep += 1;
    if (this.callsSinceSweep >= 100) {
      this.sweep(now);
    }

    return 0;
  }

  private sweep(now: number) {
    this.callsSinceSweep = 0;
    for (const [key, counter] of this.identities) {
      if (counter.resetAt <= now) this.identities.delete(key);
    }
  }
}

export const aiRateLimiter = new AiRateLimiter();
