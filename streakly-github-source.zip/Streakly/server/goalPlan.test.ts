import { describe, expect, it } from "vitest";
import { goalPlanSchema } from "../shared/goalPlan";

const validPlan = {
  title: "Read consistently",
  summary: "Build a small reading rhythm that fits around a busy work week.",
  successMetric: "Finish 12 books in a year.",
  timeframeWeeks: 12,
  milestones: [
    { title: "Set the rhythm", description: "Complete four short reading sessions each week.", week: 2 },
    { title: "Finish the first book", description: "Keep the routine comfortable and finish one book.", week: 8 },
  ],
  habits: [
    { name: "Weekday reading", emoji: "📖", category: "Mind", frequency: "Weekdays", goal: "Read for 15 minutes." },
    { name: "Weekly book check-in", emoji: "☕", category: "Life", frequency: "Weekly", goal: "Choose the next book." },
  ],
  safetyNote: "Take a short break if your eyes feel tired.",
};

describe("goalPlanSchema", () => {
  it("accepts a bounded plan with milestones and habits", () => {
    expect(goalPlanSchema.safeParse(validPlan).success).toBe(true);
  });

  it("rejects milestones outside or out of order within the timeframe", () => {
    const result = goalPlanSchema.safeParse({
      ...validPlan,
      milestones: [
        { ...validPlan.milestones[0], week: 13 },
        { ...validPlan.milestones[1], week: 8 },
      ],
    });
    expect(result.success).toBe(false);
  });

  it("rejects habit frequencies outside the tracker options", () => {
    const result = goalPlanSchema.safeParse({
      ...validPlan,
      habits: [validPlan.habits[0], { ...validPlan.habits[1], frequency: "Monthly" }],
    });
    expect(result.success).toBe(false);
  });
});
