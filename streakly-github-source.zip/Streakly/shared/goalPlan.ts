import { z } from "zod";

export const goalPlanSchema = z.object({
  title: z.string().trim().min(4).max(80),
  summary: z.string().trim().min(20).max(320),
  successMetric: z.string().trim().min(4).max(140),
  timeframeWeeks: z.number().int().min(2).max(52),
  milestones: z.array(z.object({
    title: z.string().trim().min(3).max(80),
    description: z.string().trim().min(8).max(220),
    week: z.number().int().min(1).max(52),
  })).min(2).max(8),
  habits: z.array(z.object({
    name: z.string().trim().min(3).max(60),
    emoji: z.string().trim().min(1).max(8),
    category: z.enum(["Body", "Mind", "Life"]),
    frequency: z.enum(["Daily", "Weekdays", "3× / week", "Weekly"]),
    goal: z.string().trim().min(2).max(160),
  })).min(2).max(6),
  safetyNote: z.string().trim().min(8).max(300),
}).superRefine((plan, context) => {
  let previousWeek = 0;
  for (const [index, milestone] of plan.milestones.entries()) {
    if (milestone.week > plan.timeframeWeeks) {
      context.addIssue({
        code: z.ZodIssueCode.custom,
        path: ["milestones", index, "week"],
        message: "Milestone week must be within the plan timeframe.",
      });
    }
    if (milestone.week < previousWeek) {
      context.addIssue({
        code: z.ZodIssueCode.custom,
        path: ["milestones", index, "week"],
        message: "Milestones must be ordered by week.",
      });
    }
    previousWeek = milestone.week;
  }
});

export type GoalPlanDraft = z.infer<typeof goalPlanSchema>;

export type SavedGoal = GoalPlanDraft & {
  id: string;
  createdAt: string;
  habitIds: string[];
  completedMilestones: number[];
};
